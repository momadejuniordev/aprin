<article id="post-<?php the_ID(); ?>" <?php post_class('article-default'); ?>>
    <div class="post-inner">
        <?php aprin_post_thumbnail('post-thumbnail', false); ?>
        <div class="post-content">
            <?php
            /**
             * Functions hooked in to aprin_loop_post action.
             *
             * @see aprin_post_header          - 15
             * @see aprin_post_content         - 30
             */
            do_action('aprin_loop_post');
            ?>
        </div>
    </div>
</article><!-- #post-## -->
