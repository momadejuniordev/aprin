<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	/**
	 * Functions hooked in to aprin_page action
	 *
	 * @see aprin_page_header          - 10
	 * @see aprin_page_content         - 20
	 *
	 */
	do_action( 'aprin_page' );
	?>
</article><!-- #post-## -->
