<?php

defined('ABSPATH') || exit;

global $product;

// Ensure visibility.
if (empty($product) || !$product->is_visible()) {
    return;
}

?>
<li <?php wc_product_class('product', $product); ?>>
    <div class="product-block-list">
        <div class="left">
            <?php
            /**
             * Functions hooked in to aprin_woocommerce_list_item_title action
             *
             * @see aprin_product_label - 10 - woo
             * @see woocommerce_template_loop_product_thumbnail - 15 - woo
             * @see aprin_woocommerce_product_loop_action_start - 20 - woo
             * @nosee aprin_quickview_button - 30 - woo
             * @see aprin_woocommerce_product_loop_action_close - 40 - woo
             * @see woocommerce_template_loop_product_link_open - 40 - woo
             * @see woocommerce_template_loop_product_link_close - 40 - woo
             *
             */
            do_action('aprin_woocommerce_list_item_title');
            ?>
        </div>
        <div class="right">
            <?php
            /**
             * Functions hooked in to aprin_woocommerce_list_item_content action
             *
             * @see woocommerce_template_loop_product_title - 5 - woo
             * @see woocommerce_template_loop_rating - 10 - woo
             * @nosee aprin_wishlist_button - 6 - woo
             * @nosee aprin_woocommerce_get_product_category - 15 - woo
             * @see woocommerce_template_loop_price - 20 - woo
             * @nosee aprin_stock_label - 20 - woo
             * @see aprin_single_product_extra_label - 25 - woo
             * @nosee aprin_woocommerce_get_product_description - 30 - woo
             * @nosee woocommerce_template_loop_add_to_cart - 35 - woo
             * @see aprin_woocommerce_render_color - 40
             *
             */
            do_action('aprin_woocommerce_list_item_content');
            ?>
        </div>
    </div>
</li>
