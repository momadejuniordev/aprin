<?php
/**
 * Product quantity inputs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/quantity-input.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 10.1.0
 *  *
 * @var bool $readonly If the input should be set to readonly mode.
 * @var string $type The input type attribute.
 */

defined('ABSPATH') || exit;

/* translators: %s: Quantity. */
$label = ! empty( $args['product_name'] ) ? sprintf( esc_html__( '%s quantity', 'aprin' ), wp_strip_all_tags( $args['product_name'] ) ) : esc_html__( 'Quantity', 'aprin' );

?>
<div class="quantity_wrap">
    <label class="quantity_label" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_attr($label); ?></label>
    <div class="quantity">
        <?php do_action('woocommerce_before_quantity_input_field'); ?>
        <input
                type="<?php echo esc_attr( $type ); ?>"
                <?php echo $readonly ? 'readonly="readonly"' : ''; ?>
                id="<?php echo esc_attr( $input_id ); ?>"
                class="<?php echo esc_attr( join( ' ', (array) $classes ) ); ?>"
                name="<?php echo esc_attr( $input_name ); ?>"
                value="<?php echo esc_attr( $input_value ); ?>"
                aria-label="<?php esc_attr_e( 'Product quantity', 'aprin' ); ?>"
                <?php if ( in_array( $type, array( 'text', 'search', 'tel', 'url', 'email', 'password' ), true ) ) : ?>
                    size="4"
                <?php endif; ?>
                min="<?php echo esc_attr( $min_value ); ?>"
                <?php if ( 0 < $max_value ) : ?>
                    max="<?php echo esc_attr( $max_value ); ?>"
                <?php endif; ?>
                <?php if ( ! $readonly ) : ?>
                    step="<?php echo esc_attr( $step ); ?>"
                    placeholder="<?php echo esc_attr( $placeholder ); ?>"
                    inputmode="<?php echo esc_attr( $inputmode ); ?>"
                    autocomplete="<?php echo esc_attr( isset( $autocomplete ) ? $autocomplete : 'on' ); ?>"
                <?php endif; ?>
        />
        <?php do_action('woocommerce_after_quantity_input_field'); ?>
    </div>
</div>
