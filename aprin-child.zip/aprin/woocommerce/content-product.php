<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined('ABSPATH') || exit;

global $product;

// Ensure visibility.
if (empty($product) || !$product->is_visible()) {
    return;
}
$class = '';
if (wc_get_loop_prop('enable_carousel', false) == true) {
    $class = 'swiper-slide';
}
?>
<li <?php wc_product_class($class, $product); ?>>
    <?php
    /**
     * Functions hooked in to woocommerce_before_shop_loop_item action
     *
     * @removed woocommerce_template_loop_product_link_open - 10
     * @see aprin_product_block_wrapper_start - 0
     * @see aprin_product_transition_wrapper_start - 5
     */
    do_action('woocommerce_before_shop_loop_item');

    /**
     * Functions hooked in to woocommerce_before_shop_loop_item_title action
     *
     * @removed woocommerce_show_product_loop_sale_flash - 10
     * @removed woocommerce_template_loop_product_thumbnail - 10
     * @see  aprin_template_loop_product_thumbnail - 10
     * @see  aprin_product_label - 10
     * @see  aprin_woocommerce_product_loop_action_start - 15
     * @see  aprin_wishlist_button - 20
     * @see  aprin_compare_button - 25
     * @see  aprin_quickview_button - 30
     * @see  aprin_woocommerce_product_loop_action_close - 35
     * @see  woocommerce_template_loop_product_link_open - 50
     * @see  woocommerce_template_loop_product_link_close - 50
     * @see  aprin_product_transition_wrapper_close - 99
     */
    do_action('woocommerce_before_shop_loop_item_title');

    /**
     * Functions hooked in to woocommerce_shop_loop_item_title action
     *
     * @see woocommerce_template_loop_rating - 10
     * @see aprin_product_caption_wrapper_start - 0
     *
     */
    do_action('woocommerce_shop_loop_item_title');

    /**
     * Functions hooked in to woocommerce_after_shop_loop_item_title action
     *
     * @hooked woocommerce_template_loop_rating - 5
     * @hooked woocommerce_template_loop_price - 10
     * @removed woocommerce_template_loop_rating - 5
     * @see woocommerce_template_loop_add_to_cart - 15

     *
     */
    do_action('woocommerce_after_shop_loop_item_title');

    /**
     * Functions hooked in to woocommerce_after_shop_loop_item action
     *
     * @removed woocommerce_template_loop_product_link_close - 5
     * @removed woocommerce_template_loop_add_to_cart - 10
     * @see aprin_woocommerce_render_color - 90
     * @see aprin_product_caption_wrapper_close - 90
     * @see aprin_product_block_wrapper_close - 95
     */
    do_action('woocommerce_after_shop_loop_item');
    ?>
</li>
