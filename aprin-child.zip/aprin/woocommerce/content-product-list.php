<?php

defined('ABSPATH') || exit;

global $product;

// Ensure visibility.
if (empty($product) || !$product->is_visible()) {
    return;
}
?>
<li <?php wc_product_class('product-list', $product); ?>>
    <div class="product-block-list">
        <?php
        /**
         * Functions hooked in to aprin_woocommerce_before_shop_loop_item action
         *
         */
        do_action('aprin_woocommerce_before_shop_loop_item');

        ?>
        <div class="product-transition">
            <?php
            /**
             * Functions hooked in to aprin_woocommerce_before_shop_loop_item_image action
             *
             * @see aprin_product_label - 10 - woo
             * @see woocommerce_template_loop_product_thumbnail - 15 - woo
             * @see aprin_woocommerce_product_loop_action_start - 20 - woo
             * @nosee aprin_quickview_button - 30 - woo
             * @see aprin_woocommerce_product_loop_action_close - 40 - woo
             * @see woocommerce_template_loop_product_link_open - 40 - woo
             * @see woocommerce_template_loop_product_link_close - 40 - woo
             */
            do_action('aprin_woocommerce_before_shop_loop_item_image');
            ?>
        </div>
        <div class="product-caption">
            <?php
            /**
             * Functions hooked in to aprin_woocommerce_shop_loop_item_caption action
             *
             * @see woocommerce_template_loop_product_title - 5 - woo
             * @see woocommerce_template_loop_rating - 10 - woo
             * @nosee aprin_wishlist_button - 6 - woo
             * @nosee aprin_woocommerce_get_product_category - 15 - woo
             * @see woocommerce_template_loop_price - 20 - woo
             * @nosee aprin_stock_label - 20 - woo
             * @see aprin_single_product_extra_label - 25 - woo
             * @see aprin_woocommerce_get_product_description - 30 - woo
             * @see woocommerce_template_loop_add_to_cart - 35 - woo
             * @see aprin_woocommerce_render_color - 40

             * @nosee aprin_quickview_button - 45 - woo
             * @nosee aprin_compare_button - 50 - woo
             */
            do_action('aprin_woocommerce_shop_loop_item_caption');
            ?>
        </div>
        <?php
        /**
         * Functions hooked in to aprin_woocommerce_after_shop_loop_item action
         *
         */
        do_action('aprin_woocommerce_after_shop_loop_item');
        ?>
    </div>
</li>
