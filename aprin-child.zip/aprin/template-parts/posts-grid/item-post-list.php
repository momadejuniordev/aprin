<article id="post-<?php the_ID(); ?>" <?php post_class('blog-style-list'); ?>>
    <div class="post-inner">
            <?php aprin_post_thumbnail('aprin-post-grid', false); ?>
        <div class="post-content">
            <div class="entry-content">
                <?php the_title('<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>
                <div class="entry-meta">
                    <?php aprin_post_meta(['show_cat' => true, 'show_date' => true, 'show_author' => true, 'show_comment' => false]); ?>
                </div>
                <div class="excerpt-content"><?php echo wp_trim_words(get_the_excerpt(), 35); ?></div>
                <div class="more-link-wrap">
                    <a class="more-link" href="<?php the_permalink() ?>">
                        <?php echo esc_html__('Read More', 'aprin'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</article><!-- #post-## -->