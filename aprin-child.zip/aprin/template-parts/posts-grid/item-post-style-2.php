<article class="post-style-2">
    <div class="post-inner">
        <?php aprin_post_thumbnail('aprin-post-grid-2', false); ?>
        <div class="post-content">
            <div class="entry-content">
                <div class="author-avatar">
                    <img src="<?php echo esc_url(get_avatar_url(get_the_author_meta('ID'))); ?>" alt=""/>
                </div>
                <div class="entry-meta">
                    <?php aprin_post_meta(['show_cat' => true, 'show_author' => false, 'show_date' => true, 'show_comment' => false]); ?>
                </div>
                <?php the_title('<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>
            </div>
        </div>
    </div>
</article>
