<article class="post-style-1">
    <div class="post-inner">
            <?php aprin_post_thumbnail('aprin-post-grid-2', false); ?>
        <div class="post-content">
            <div class="entry-content">
                <div class="entry-meta">
                    <?php aprin_post_meta(['show_cat' => true, 'show_author' => true, 'show_date' => true, 'show_comment' => false]); ?>
                </div>
                <?php the_title('<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>
                <div class="excerpt-content"><?php echo wp_trim_words(get_the_excerpt(), 35); ?></div>
            </div>
        </div>
    </div>
</article>
