<header id="masthead" class="site-header header-1" role="banner">
    <div class="header-container">
        <div class="header-main">
            <div class="header-left">
                <?php
                aprin_site_branding();
                if (aprin_is_woocommerce_activated()) {
                    ?>
                    <div class="site-header-cart header-cart-mobile">
                        <?php aprin_cart_link(); ?>
                    </div>
                    <?php
                }
                ?>
                <?php aprin_mobile_nav_button(); ?>
            </div>
            <div class="header-center">
                <?php aprin_primary_navigation(); ?>
            </div>
            <div class="header-right desktop-hide-down">
                <div class="header-group-action">
                    <?php
                    aprin_header_account();
                    if (aprin_is_woocommerce_activated()) {
                        aprin_header_wishlist();
                        aprin_header_cart();
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</header><!-- #masthead -->
