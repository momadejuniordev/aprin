<?php
$theme = wp_get_theme('aprin');
define('APRIN_VERSION', $theme['Version']);

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if (!isset($content_width)) {
    $content_width = 980; /* pixels */
}
require get_theme_file_path('inc/class-tgm-plugin-activation.php');
$aprin = (object)array(
    'version' => APRIN_VERSION,
    /**
     * Initialize all the things.
     */
    'main'    => require 'inc/class-main.php',
);
require get_theme_file_path('inc/functions.php');
require get_theme_file_path('inc/template-hooks.php');
require get_theme_file_path('inc/template-functions.php');

add_action('after_setup_theme', function () {
    require_once get_theme_file_path('inc/merlin/vendor/autoload.php');
    require_once get_theme_file_path('inc/merlin/class-merlin.php');
    require_once get_theme_file_path('inc/merlin-config.php');

    require_once get_theme_file_path('inc/merlin/includes/class-color-picker-in-category.php');
    require get_theme_file_path('inc/merlin/includes/class-custom-post-type.php');
    $files = glob(trailingslashit(get_template_directory()) . 'inc/merlin/includes/post-type/*.php');
    foreach ($files as $file) {
        require $file;
    }
    require get_theme_file_path('inc/merlin/includes/class-custom-post-type-setting.php');
});

require_once get_theme_file_path('inc/class-customize.php');

if (aprin_is_woocommerce_activated()) {
    $aprin->woocommerce = require get_theme_file_path('inc/woocommerce/class-woocommerce.php');

    require_once get_theme_file_path('inc/woocommerce/class-woocommerce-adjacent-products.php');
    require_once get_theme_file_path('inc/woocommerce/class-product-category-walker.php');
    require_once get_theme_file_path('inc/woocommerce/woocommerce-functions.php');
//    require_once get_theme_file_path('inc/woocommerce/template-hooks.php');
    require_once get_theme_file_path('inc/woocommerce/woocommerce-template-hooks.php');

    add_action('after_setup_theme', function () {
        require_once get_theme_file_path('inc/woocommerce/class-woocommerce-settings.php');
    });

    require_once get_theme_file_path('inc/woocommerce/class-woocommerce-brand.php');
    require_once get_theme_file_path('inc/woocommerce/class-woocommerce-extra.php');
    require_once get_theme_file_path('inc/merlin/includes/product-360-view.php');
    require_once get_theme_file_path('inc/merlin/includes/product-labels/product-labels.php');
}

if (aprin_is_elementor_activated()) {
    require get_theme_file_path('inc/elementor/functions-elementor.php');
    $aprin->elementor = require get_theme_file_path('inc/elementor/class-elementor.php');
    //====start_premium
    $aprin->megamenu = require get_theme_file_path('inc/megamenu/megamenu.php');
    //====end_premium
    $aprin->parallax      = require get_theme_file_path('inc/elementor/class-section-parallax.php');
    $aprin->muntiparallax = require get_theme_file_path('inc/merlin/includes/class-parallax.php');

    if (defined('ELEMENTOR_PRO_VERSION')) {
        require get_theme_file_path('inc/elementor/functions-elementor-pro.php');
    }

    if (function_exists('hfe_init')) {
        require get_theme_file_path('inc/header-footer-elementor/class-hfe.php');
        require get_theme_file_path('inc/merlin/includes/breadcrumb.php');
        require get_theme_file_path('inc/merlin/includes/class-custom-shapes.php');
    }
    if (aprin_is_woocommerce_activated()) {
        require_once get_theme_file_path('inc/elementor/elementor-control/class-elementor-control.php');
    }
}

if (!is_user_logged_in()) {
    require get_theme_file_path('inc/modules/class-login.php');
}

add_action('wp_footer', function() {
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const form = document.querySelector('.jet-form-builder');
        if (form) {
            // Check if wrapper already exists
            if (document.querySelector('.price-summary-card')) return;
            
            const calcFields = document.querySelectorAll('.jet-form-builder-row.field-type-calculated-field');
            const submitBtn = document.querySelector('.jet-form-builder-row.field-type-submit-field');
            
            if (calcFields.length > 0) {
                const wrapper = document.createElement('div');
                wrapper.className = 'price-summary-card';
                
                // Insert wrapper before the first calc field
                calcFields[0].parentNode.insertBefore(wrapper, calcFields[0]);
                
                // Move calc fields into wrapper
                calcFields.forEach(function(field) {
                    wrapper.appendChild(field);
                });
                
                // Move submit into wrapper
                if (submitBtn) {
                    wrapper.appendChild(submitBtn);
                }
            }
        }
    });
    </script>
    <?php
});