<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="single-content">
        <?php
        /**
         * Functions hooked in to aprin_single_post_top action
         *
         */
        do_action('aprin_single_post_top');

        /**
         * Functions hooked in to aprin_single_post action
         * @see aprin_post_header         - 10
         * @see aprin_post_content         - 30
         */
        do_action('aprin_single_post');

        /**
         * Functions hooked in to aprin_single_post_bottom action
         *
         * @see aprin_post_taxonomy       - 5
         * @see aprin_post_nav            - 10
         * @see aprin_display_comments    - 20
         */
        do_action('aprin_single_post_bottom');
        ?>

    </div>

</article><!-- #post-## -->
