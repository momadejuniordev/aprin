(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', () => {
        elementorFrontend.hooks.addAction('frontend/element_ready/aprin-nav-menu-vertical.default', ($element) => {
            var menuItems = $element.find("ul li.menu-item-has-children");
            menuItems.each(function () {
                var dropdownItems = $(this).find(" > ul"),
                    menuItem = this,
                    anchor = $(this).find("> a"),
                    animationSpeed = "fast";
                anchor.on("click tap", function (e) {
                    e.preventDefault();
                    e.stopPropagation();

                    if (dropdownItems.is(":visible")) {
                        $(menuItem).removeClass("aprin-menu-item--open");
                        dropdownItems.fadeOut(animationSpeed);
                    } else {
                        if (anchor.parent().parent().children().hasClass("aprin-menu-item--open") &&
                            anchor.parent().parent().parent().hasClass("vertical-menu")) {
                            $(this).parent().parent().children().removeClass("aprin-menu-item--open");
                            $(this).parent().parent().children().find(" > ul").fadeOut(animationSpeed);
                        } else {
                            if (!$(this).parents("li").hasClass("aprin-menu-item--open")) {
                                menuItems.removeClass("aprin-menu-item--open");
                                menuItems.find(" > .qodef-drop-down-second, > ul").fadeOut(animationSpeed);
                            }

                            if (anchor.parent().parent().children().hasClass("aprin-menu-item--open")) {
                                $(this).parent().parent().children().removeClass("aprin-menu-item--open");
                                $(this).parent().parent().children().find(" > ul").fadeOut(animationSpeed);
                            }
                        }

                        $(menuItem).addClass("aprin-menu-item--open");
                        dropdownItems.fadeIn("slow");
                    }
                });
            });
        });
    });
})(jQuery);