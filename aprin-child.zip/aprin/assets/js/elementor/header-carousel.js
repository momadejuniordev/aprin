(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', () => {
        elementorFrontend.hooks.addAction('frontend/element_ready/aprin-header-carousel.default',  ($element) => {
            let addHandler = $('.aprin-swiper-wrapper', $element);
            if (addHandler.length > 0) {
                elementorFrontend.elementsHandler.addHandler(aprinSwiperBase, {
                    $element,
                });
            }
        });
    });
})(jQuery);