// (function ($) {
//     "use strict";
//     $(window).on('elementor/frontend/init', () => {
//         elementorFrontend.hooks.addAction('frontend/element_ready/aprin-elementor-custom-printing.default', ($scope) => {
//             document.querySelectorAll(".elementor-custom-printing-wrapper .aprin-con-inner .elementor-custom-printing-item").forEach(li => {
//                 li.addEventListener("mouseover", e => {
//                     document.querySelectorAll(`#${e.target.id}`)[1].classList.add("active");
//                 });
//                 li.addEventListener("mouseout", e => {
//                     document.querySelectorAll(`#${e.target.id}`)[1].classList.remove("active");
//                 });
//             });
//         });
//     });
// })(jQuery);