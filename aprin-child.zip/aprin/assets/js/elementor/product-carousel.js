(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', () => {
        elementorFrontend.hooks.addAction('frontend/element_ready/aprin-product-carousel.default', function ($scope) {
            const $element = $scope.find('.aprin-product-carousel-swiper');
            if($element.length > 0) {
                const swiper = new Swiper(".aprin-product-carousel-swiper", {
                    direction: "horizontal",
                    slidesPerView: 1,
                    spaceBetween: 0,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                    loop: true,
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true
                    },
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false,
                    },
                });
            }
        });
    });
})(jQuery);



