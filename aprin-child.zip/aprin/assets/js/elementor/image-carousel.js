(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', () => {
        elementorFrontend.hooks.addAction('frontend/element_ready/aprin-image-carousel.default', function ($scope) {
            var swiper2 = new Swiper(".mySwiper", {
                spaceBetween: 30,
                slidesPerView: 5,
                breakpoints: {
                    320: {
                        slidesPerView: 1,
                    },
                    768: {
                        slidesPerView: 2,
                    },
                    1024: {
                        slidesPerView: 3,
                    },
                    1200: {
                        slidesPerView: 4,
                    },
                    1440: {
                        slidesPerView: 5,
                    },
                },
                //centeredSlides: true,
                loop: true,
                autoplay: {
                    delay: 0,
                    disableOnInteraction: false,
                },
                speed:5000,
            });

            $('.swiper-slide').hover(function(){
                swiper2.autoplay.stop();
            }, function(){
                swiper2.autoplay.start();
            });
        });
    });
})(jQuery);