class AprinTheme {

}

$(document).ready(function () {
    new AprinTheme();
})
