<?php
/**
 * The loop template file.
 *
 * Included on pages like index.php, archive.php and search.php to display a loop of posts
 * Learn more: https://codex.wordpress.org/The_Loop
 *
 * @package aprin
 */

do_action('aprin_loop_before');

$blog_style  = aprin_get_theme_option('blog_style', 'standard');

$allowed_styles = [ 'standard', 'style-1', 'list'];
$check_style = in_array( $blog_style, $allowed_styles, true ) && ($blog_style !== 'standard') ? true : false;
$blog_style = in_array( $blog_style, $allowed_styles, true ) ? $blog_style : 'standard';

$class       = array();
//$class[]     = 'blog-style-' . $blog_style;
if ($check_style) {
    if ($blog_style == 'list') {
        $class[] = 'elementor-grid-1';
    } else {
        $class[] = 'blog-style-grid';
        $class[] = 'elementor-grid-' . aprin_get_theme_option('blog_columns', 3);
        $class[] = 'elementor-grid-laptop-' . aprin_get_theme_option('blog_columns_laptop', 3);
        $class[] = 'elementor-grid-tablet-' . aprin_get_theme_option('blog_columns_tablet', 2);
        $class[] = 'elementor-grid-mobile-' . aprin_get_theme_option('blog_columns_mobile', 1);
    }
}

$class = esc_attr(implode(' ', array_unique($class)));
?>
    <div class="<?php echo esc_attr($class) ?>">
        <div class="elementor-grid">
            <?php
            $count = 0;
            $class = '';
            while (have_posts()) :
                the_post();
                /**
                 * Include the Post-Format-specific template for the content.
                 * If you want to override this in a child theme, then include a file
                 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                 */
                if ($check_style) {
                    get_template_part('template-parts/posts-grid/item-post-' . $blog_style);
                } else {
                    get_template_part('content', get_post_format());
                }

            endwhile; ?>
        </div>
    </div>
<?php

/**
 * Functions hooked in to aprin_loop_after action
 *
 * @see aprin_paging_nav - 10
 */
do_action('aprin_loop_after');