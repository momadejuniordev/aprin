<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('Aprin_Customize')) {

    class Aprin_Customize {


        public function __construct() {
            add_action('customize_register', array($this, 'customize_register'));
        }

        public function get_banner() {
            global $post;

            $options[''] = esc_html__('Select Banner', 'aprin');
            if (!aprin_is_elementor_activated()) {
                return;
            }
            $args = array(
                'post_type'      => 'elementor_library',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                's'              => 'Banner ',
                'order'          => 'ASC',
            );

            $query1 = new WP_Query($args);
            while ($query1->have_posts()) {
                $query1->the_post();
                $options[$post->post_name] = $post->post_title;
            }

            wp_reset_postdata();
            return $options;
        }

        /**
         * @param $wp_customize WP_Customize_Manager
         */
        public function tesst($wp_customize) {
            $wp_customize->add_control(
                new WP_Customize_Image_Control(
                    $wp_customize,
                    'dav_bgImage',
                    array(
                        'label'    => esc_attr__('Background image', 'aprin'),
                        'section'  => 'dav_display_options',
                        'settings' => 'dav_bgImage',
                        'priority' => 8
                    )
                )
            );
        }

        public function customize_register($wp_customize) {

            /**
             * Theme options.
             */
            require_once get_theme_file_path('inc/customize-control/editor.php');
            $this->init_aprin_blog($wp_customize);
            $this->aprin_register_theme_customizer($wp_customize);


            if (aprin_is_woocommerce_activated()) {
                $this->init_woocommerce($wp_customize);
            }

            do_action('aprin_customize_register', $wp_customize);
        }

        function aprin_register_theme_customizer($wp_customize) {

        } // end aprin_register_theme_customizer

        /**
         * @param $wp_customize WP_Customize_Manager
         *
         * @return void
         */
        public function init_aprin_blog($wp_customize) {

            $wp_customize->add_panel('aprin_blog', array(
                'title' => esc_html__('Blog', 'aprin'),
            ));

            // =========================================
            // Blog Archive
            // =========================================
            $wp_customize->add_section('aprin_blog_archive', array(
                'title'      => esc_html__('Archive', 'aprin'),
                'panel'      => 'aprin_blog',
                'capability' => 'edit_theme_options',
            ));

            $wp_customize->add_setting('aprin_options_blog_sidebar', array(
                'type'              => 'option',
                'default'           => 'left',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_sidebar', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Sidebar Position', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'none'  => esc_html__('None', 'aprin'),
                    'left'  => esc_html__('Left', 'aprin'),
                    'right' => esc_html__('Right', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_blog_style', array(
                'type'              => 'option',
                'default'           => 'standard',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_style', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Blog style', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'standard' => esc_html__('Blog Standard', 'aprin'),
                    'list'     => esc_html__('Blog List', 'aprin'),
                    'style-1'  => esc_html__('Blog Grid', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_blog_columns', array(
                'type'              => 'option',
                'default'           => 3,
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_columns', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Colunms', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    1 => esc_html__('1', 'aprin'),
                    2 => esc_html__('2', 'aprin'),
                    3 => esc_html__('3', 'aprin'),
                    4 => esc_html__('4', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_blog_columns_laptop', array(
                'type'              => 'option',
                'default'           => 3,
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_columns_laptop', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Colunms Laptop', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    1 => esc_html__('1', 'aprin'),
                    2 => esc_html__('2', 'aprin'),
                    3 => esc_html__('3', 'aprin'),
                    4 => esc_html__('4', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_blog_columns_tablet', array(
                'type'              => 'option',
                'default'           => 2,
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_columns_tablet', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Colunms Tablet', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    1 => esc_html__('1', 'aprin'),
                    2 => esc_html__('2', 'aprin'),
                    3 => esc_html__('3', 'aprin'),
                    4 => esc_html__('4', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_blog_columns_mobile', array(
                'type'              => 'option',
                'default'           => 1,
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_columns_mobile', array(
                'section' => 'aprin_blog_archive',
                'label'   => esc_html__('Colunms Mobile', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    1 => esc_html__('1', 'aprin'),
                    2 => esc_html__('2', 'aprin'),
                    3 => esc_html__('3', 'aprin'),
                    4 => esc_html__('4', 'aprin'),
                ),
            ));

            // =========================================
            // Blog Single
            // =========================================
            $wp_customize->add_section('aprin_blog_single', array(
                'title'      => esc_html__('Singular', 'aprin'),
                'panel'      => 'aprin_blog',
                'capability' => 'edit_theme_options',
            ));
            $wp_customize->add_setting('aprin_options_blog_single_sidebar', array(
                'type'              => 'option',
                'default'           => 'left',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_blog_single_sidebar', array(
                'section' => 'aprin_blog_single',
                'label'   => esc_html__('Sidebar Position', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'none'  => esc_html__('None', 'aprin'),
                    'left'  => esc_html__('Left', 'aprin'),
                    'right' => esc_html__('Right', 'aprin'),
                ),
            ));
        }

        /**
         * @param $wp_customize WP_Customize_Manager
         *
         * @return void
         */


        public function init_woocommerce($wp_customize) {

            $wp_customize->add_panel('woocommerce', array(
                'title' => esc_html__('Woocommerce', 'aprin'),
            ));

            $wp_customize->add_section('aprin_woocommerce_archive', array(
                'title'      => esc_html__('Archive', 'aprin'),
                'capability' => 'edit_theme_options',
                'panel'      => 'woocommerce',
                'priority'   => 1,
            ));

            $wp_customize->add_setting('aprin_options_woocommerce_archive_content_width', array(
                'type'              => 'option',
                'default'           => 'default',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_woocommerce_archive_content_width', array(
                'section' => 'aprin_woocommerce_archive',
                'label'   => esc_html__('Content Width', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'default' => esc_html__('default', 'aprin'),
                    'wide'    => esc_html__('Wide', 'aprin'),

                ),
            ));

            $wp_customize->add_setting('aprin_options_woocommerce_archive_layout', array(
                'type'              => 'option',
                'default'           => 'default',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_woocommerce_archive_layout', array(
                'section' => 'aprin_woocommerce_archive',
                'label'   => esc_html__('Sidebar Position', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'default'  => esc_html__('Sidebar', 'aprin'),
                    //====start_premium
                    'canvas'   => esc_html__('Canvas Filter', 'aprin'),
                    'menu'     => esc_html__('Menu Filter', 'aprin'),
                    'dropdown' => esc_html__('Dropdown Filter', 'aprin'),
                    //====end_premium
                ),
            ));

            $wp_customize->add_setting('aprin_options_woocommerce_product_layout', array(
                'type'              => 'option',
                'default'           => 'grid',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_woocommerce_product_layout', array(
                'section' => 'aprin_woocommerce_archive',
                'label'   => esc_html__('Product layout', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'grid' => esc_html__('Grid', 'aprin'),
                    'list' => esc_html__('List', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_woocommerce_archive_sidebar', array(
                'type'              => 'option',
                'default'           => 'left',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_woocommerce_archive_sidebar', array(
                'section' => 'aprin_woocommerce_archive',
                'label'   => esc_html__('Sidebar Position', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'left'  => esc_html__('Left', 'aprin'),
                    'right' => esc_html__('Right', 'aprin'),
                ),
            ));

            $wp_customize->add_setting('aprin_options_woocommerce_shop_pagination', array(
                'type'              => 'option',
                'default'           => 'default',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_woocommerce_shop_pagination', array(
                'section' => 'aprin_woocommerce_archive',
                'label'   => esc_html__('Products pagination', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'default'  => esc_html__('Pagination', 'aprin'),
                    'more-btn' => esc_html__('Load More', 'aprin'),
                    'infinit'  => esc_html__('Infinit Scroll', 'aprin'),
                ),
            ));

            if (aprin_is_elementor_activated()) {

                $wp_customize->add_setting('aprin_options_shop_banner', array(
                    'type'              => 'option',
                    'default'           => '',
                    'sanitize_callback' => 'sanitize_text_field',
                ));

                $wp_customize->add_control('aprin_options_shop_banner', array(
                    'section'     => 'aprin_woocommerce_archive',
                    'label'       => esc_html__('Banner', 'aprin'),
                    'type'        => 'select',
                    'description' => __('Banner will take templates name prefix is "Banner"', 'aprin'),
                    'choices'     => $this->get_banner()
                ));

            }


            // =========================================
            // Single Product
            // =========================================

            $wp_customize->add_section('aprin_woocommerce_single', array(
                'title'      => esc_html__('Singular', 'aprin'),
                'capability' => 'edit_theme_options',
                'panel'      => 'woocommerce',
                'priority'   => 1,
            ));

            $wp_customize->add_setting('aprin_options_single_product_gallery_layout', array(
                'type'              => 'option',
                'default'           => 'horizontal',
                'transport'         => 'refresh',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('aprin_options_single_product_gallery_layout', array(
                'section' => 'aprin_woocommerce_single',
                'label'   => esc_html__('Style', 'aprin'),
                'type'    => 'select',
                'choices' => array(
                    'horizontal' => esc_html__('Horizontal', 'aprin'),
                    //====start_premium
                    'vertical'   => esc_html__('Vertical', 'aprin'),
                    'gallery'    => esc_html__('Gallery', 'aprin'),
                    'sticky'     => esc_html__('Sticky', 'aprin'),
                    //====end_premium
                ),
            ));

            $wp_customize->add_setting(
                'aprin_options_single_product_content_meta',
                array(
                    /* translators: %s privacy policy page name and link */
                    'type'              => 'option',
                    'sanitize_callback' => 'wp_kses_post',
                    'capability'        => 'edit_theme_options',
                    'transport'         => 'postMessage',
                )
            );

            $wp_customize->add_control(
                'aprin_options_single_product_content_meta',
                array(

                    'label'    => esc_html__('Single extra description', 'aprin'),
                    'section'  => 'aprin_woocommerce_single',
                    'settings' => 'aprin_options_single_product_content_meta',
                    'type'     => 'textarea',
                )
            );

            // =========================================
            // Product
            // =========================================
            $wp_customize->add_setting('aprin_options_wocommerce_row_laptop', array(
                'type'              => 'option',
                'default'           => 3,
                'transport'         => 'postMessage',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_wocommerce_row_laptop', array(
                'section' => 'woocommerce_product_catalog',
                'label'   => esc_html__('Products per row Laptop', 'aprin'),
                'type'    => 'number',
            ));

            $wp_customize->add_setting('aprin_options_wocommerce_row_tablet', array(
                'type'              => 'option',
                'default'           => 2,
                'transport'         => 'postMessage',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_wocommerce_row_tablet', array(
                'section' => 'woocommerce_product_catalog',
                'label'   => esc_html__('Products per row tablet', 'aprin'),
                'type'    => 'number',
            ));

            $wp_customize->add_setting('aprin_options_wocommerce_row_mobile', array(
                'type'              => 'option',
                'default'           => 1,
                'transport'         => 'postMessage',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('aprin_options_wocommerce_row_mobile', array(
                'section' => 'woocommerce_product_catalog',
                'label'   => esc_html__('Products per row mobile', 'aprin'),
                'type'    => 'number',
            ));

        }
    }
}
return new Aprin_Customize();
