<?php

if (!function_exists('aprin_display_comments')) {
    /**
     * Aprin display comments
     *
     * @since  1.0.0
     */
    function aprin_display_comments() {
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || 0 !== intval(get_comments_number())) :
            comments_template();
        endif;
    }
}

if (!function_exists('aprin_comment')) {
    /**
     * Aprin comment template
     *
     * @param array $comment the comment array.
     * @param array $args the comment args.
     * @param int $depth the comment depth.
     *
     * @since 1.0.0
     */
    function aprin_comment($comment, $args, $depth) {
        if ('div' === $args['style']) {
            $tag       = 'div';
            $add_below = 'comment';
        } else {
            $tag       = 'li';
            $add_below = 'div-comment';
        }
        ?>
        <<?php echo esc_attr($tag) . ' '; ?><?php comment_class(empty($args['has_children']) ? '' : 'parent'); ?> id="comment-<?php comment_ID(); ?>">

        <div class="comment-body">
            <div class="comment-author vcard">
                <?php echo get_avatar($comment, 50); ?>
            </div>
            <?php if ('div' !== $args['style']) : ?>
            <div id="div-comment-<?php comment_ID(); ?>" class="comment-content">
                <?php endif; ?>
                <div class="comment-head">
                    <div class="comment-meta commentmetadata">
                        <?php printf('<cite class="fn">%s</cite>', get_comment_author_link()); ?>

                        <?php
                        printf(
                            '<a href="%s" class="comment-date"><time datetime="%s">%s</time></a>',
                            esc_url(get_comment_link($comment, $args)),
                            get_comment_time('c'),
                            sprintf(
                            /* translators: 1: Comment date, 2: Comment time. */
                                __('%1$s at %2$s', 'aprin'),
                                get_comment_date('', $comment),
                                get_comment_time()
                            )
                        );

                        ?>

                        <?php if ('0' === $comment->comment_approved) : ?>
                            <em class="comment-awaiting-moderation"><?php esc_attr_e('Your comment is awaiting moderation.', 'aprin'); ?></em>
                            <br/>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="comment-text">
                    <?php comment_text(); ?>
                </div>

                <div class="reply">
                    <?php
                    comment_reply_link(
                        array_merge(
                            $args, array(
                                'add_below' => $add_below,
                                'depth'     => $depth,
                                'max_depth' => $args['max_depth'],
                            )
                        )
                    );
                    ?>
                    <?php edit_comment_link(esc_html__('Edit', 'aprin'), '  ', ''); ?>
                </div>
                <?php if ('div' !== $args['style']) : ?>
            </div>
        <?php endif; ?>
        </div>
        <?php
    }
}

if (!function_exists('aprin_credit')) {
    /**
     * Display the theme credit
     *
     * @return void
     * @since  1.0.0
     */
    function aprin_credit() {
        ?>
        <div class="site-info">
            <?php echo apply_filters('aprin_copyright_text', $content = '&copy; ' . date('Y') . ' ' . '<a class="site-url" href="' . esc_url(site_url()) . '">' . esc_html(get_bloginfo('name')) . '</a>' . esc_html__('. All Rights Reserved.', 'aprin')); ?>
        </div><!-- .site-info -->
        <?php
    }
}

if (!function_exists('aprin_social')) {
    function aprin_social() {
        $social_list = aprin_get_theme_option('social_text', []);
        if (empty($social_list)) {
            return;
        }
        ?>
        <div class="aprin-social">
            <ul>
                <?php

                foreach ($social_list as $social_item) {
                    ?>
                    <li><a href="<?php echo esc_url($social_item); ?>"></a></li>
                    <?php
                }
                ?>

            </ul>
        </div>
        <?php
    }
}

if (!function_exists('aprin_site_branding')) {
    /**
     * Site branding wrapper and display
     *
     * @return void
     * @since  1.0.0
     */
    function aprin_site_branding() {
        ?>
        <div class="site-branding">
            <?php echo aprin_site_title_or_logo(); ?>
        </div>
        <?php
    }
}

if (!function_exists('aprin_site_title_or_logo')) {
    /**
     * Display the site title or logo
     *
     * @param bool $echo Echo the string or return it.
     *
     * @return string
     * @since 2.1.0
     */
    function aprin_site_title_or_logo() {
        ob_start();
        the_custom_logo(); ?>
        <div class="site-branding-text">
            <?php if (is_front_page()) : ?>
                <h1 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>"
                                          rel="home"><?php bloginfo('name'); ?></a></h1>
            <?php else : ?>
                <p class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>"
                                         rel="home"><?php bloginfo('name'); ?></a></p>
            <?php endif; ?>

            <?php
            $description = get_bloginfo('description', 'display');

            if ($description || is_customize_preview()) :
                ?>
                <p class="site-description"><?php echo esc_html($description); ?></p>
            <?php endif; ?>
        </div><!-- .site-branding-text -->
        <?php
        $html = ob_get_clean();
        return $html;
    }
}

if (!function_exists('aprin_primary_navigation')) {
    /**
     * Display Primary Navigation
     *
     * @return void
     * @since  1.0.0
     */
    function aprin_primary_navigation() {
        ?>
        <nav class="main-navigation" role="navigation"
             aria-label="<?php esc_html_e('Primary Navigation', 'aprin'); ?>">
            <?php
            $args = apply_filters('aprin_nav_menu_args', [
                'fallback_cb'     => '__return_empty_string',
                'theme_location'  => 'primary',
                'container_class' => 'primary-navigation',
                'link_before'     => '<span class="menu-title">',
                'link_after'      => '</span>'
            ]);
            wp_nav_menu($args);
            ?>
        </nav>
        <?php
    }
}

if (!function_exists('aprin_mobile_navigation')) {
    /**
     * Display Handheld Navigation
     *
     * @return void
     * @since  1.0.0
     */
    function aprin_mobile_navigation() {
        ?>
        <div class="mobile-nav-tabs">
            <ul>
                <?php if (isset(get_nav_menu_locations()['handheld'])) { ?>
                    <li class="mobile-tab-title mobile-pages-title active" data-menu="pages">
                        <span><?php echo esc_html(get_term(get_nav_menu_locations()['handheld'], 'nav_menu')->name); ?></span>
                    </li>
                <?php } ?>
                <?php if (isset(get_nav_menu_locations()['vertical'])) { ?>
                    <li class="mobile-tab-title mobile-categories-title" data-menu="categories">
                        <span><?php echo esc_html(get_term(get_nav_menu_locations()['vertical'], 'nav_menu')->name); ?></span>
                    </li>
                <?php } ?>
            </ul>
        </div>
        <nav class="mobile-menu-tab mobile-navigation mobile-pages-menu active"
             aria-label="<?php esc_html_e('Mobile Navigation', 'aprin'); ?>">
            <?php
            wp_nav_menu(
                array(
                    'theme_location'  => 'handheld',
                    'container_class' => 'handheld-navigation',
                )
            );
            ?>
        </nav>
        <nav class="mobile-menu-tab mobile-navigation-categories mobile-categories-menu"
             aria-label="<?php esc_html_e('Mobile Navigation', 'aprin'); ?>">
            <?php
            wp_nav_menu(
                array(
                    'theme_location'  => 'vertical',
                    'container_class' => 'handheld-navigation',
                )
            );
            ?>
        </nav>
        <?php
    }
}

if (!function_exists('aprin_homepage_header')) {
    /**
     * Display the page header without the featured image
     *
     * @since 1.0.0
     */
    function aprin_homepage_header() {
        edit_post_link(esc_html__('Edit this section', 'aprin'), '', '', '', 'button aprin-hero__button-edit');
        ?>
        <header class="entry-header">
            <?php
            the_title('<h1 class="entry-title">', '</h1>');
            ?>
        </header><!-- .entry-header -->
        <?php
    }
}

if (!function_exists('aprin_page_header')) {
    /**
     * Display the page header
     *
     * @since 1.0.0
     */
    function aprin_page_header() {

        if (is_front_page() || !is_page_template('default')) {
            return;
        }

        if (aprin_is_elementor_activated() && function_exists('hfe_init')) {
            if (Aprin_breadcrumb::get_template_id() !== '') {
                return;
            }
        }

        ?>
        <header class="entry-header">
            <?php
            if (has_post_thumbnail()) {
                aprin_post_thumbnail('full');
            }
            the_title('<h1 class="entry-title">', '</h1>');
            ?>
        </header><!-- .entry-header -->
        <?php
    }
}

if (!function_exists('aprin_page_content')) {
    /**
     * Display the post content
     *
     * @since 1.0.0
     */
    function aprin_page_content() {
        ?>
        <div class="entry-content">
            <?php the_content(); ?>
            <?php
            wp_link_pages(
                array(
                    'before' => '<div class="page-links">' . esc_html__('Pages:', 'aprin'),
                    'after'  => '</div>',
                )
            );
            ?>
        </div><!-- .entry-content -->
        <?php
    }
}

if (!function_exists('aprin_post_header')) {
    /**
     * Display the post header with a link to the single post
     *
     * @since 1.0.0
     */
    function aprin_post_header() {
        ?>
        <header class="entry-header">
            <?php
            if (is_single()) { ?>
                <div class="entry-meta-post">
                    <div class="entry-meta">
                        <?php aprin_post_meta(['show_cat' => true, 'show_author' => true, 'show_date' => true, 'show_comment' => false]); ?>
                    </div>
                </div>
                <?php the_title('<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>
                <?php
            } else { ?>
                <?php if ('post' == get_post_type()) { ?>
                    <div class="header-meta">
                        <div class="entry-meta-post">
                            <div class="entry-meta">
                                <?php aprin_post_meta(['show_cat' => true, 'show_author' => true, 'show_date' => true, 'show_comment' => false]); ?>
                            </div>
                        </div>
                        <?php the_title('<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>
                        <div class="entry-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 50); ?></div>
                        <?php echo '<div class="more-link-wrap"><a class="more-link" href="' . get_permalink() . '">' . esc_html__('Read More', 'aprin') . '' . '</a></div>'; ?>
                    </div>
                <?php } ?>
            <?php } ?>
        </header><!-- .entry-header -->
        <?php
    }
}

if (!function_exists('aprin_post_content')) {
    /**
     * Display the post content with a link to the single post
     *
     * @since 1.0.0
     */
    function aprin_post_content() {
        ?>
        <div class="entry-content">
            <?php

            /**
             * Functions hooked in to aprin_post_content_before action.
             *
             */
            do_action('aprin_post_content_before');


            if (is_single()) {
                the_content(
                    sprintf(
                    /* translators: %s: post title */
                        esc_html__('Read More', 'aprin') . ' %s',
                        '<span class="screen-reader-text">' . get_the_title() . '</span>'
                    )
                );
            }

            /**
             * Functions hooked in to aprin_post_content_after action.
             *
             */
            do_action('aprin_post_content_after');

            wp_link_pages(
                array(
                    'before' => '<div class="page-links">' . esc_html__('Pages:', 'aprin'),
                    'after'  => '</div>',
                )
            );
            ?>
        </div><!-- .entry-content -->
        <?php
    }
}

if (!function_exists('aprin_post_meta')) {
    /**
     * Display the post meta
     *
     * @since 1.0.0
     */
    function aprin_post_meta($atts = array()) {
        global $post;
        if ('post' !== get_post_type()) {
            return;
        }

        extract(
            shortcode_atts(
                array(
                    'show_date'    => true,
                    'show_cat'     => true,
                    'show_author'  => true,
                    'show_comment' => true,
                ),
                $atts
            )
        );

        $categories_list = aprin_get_the_category_list('');
        $categories      = '';
        if ($show_cat && $categories_list) {
            // Make sure there's more than one category before displaying.
            $categories = '<div class="categories-link"><span class="screen-reader-text">' . esc_html__('Categories', 'aprin') . '</span>' . $categories_list . '</div>';
        }

        $author = '';
        // Author.
        if ($show_author == 1) {
            $author_id = $post->post_author;
            $author    = sprintf(
                '<div class="post-author"><span>' . esc_html__('By ', 'aprin') . '<a href="%1$s" class="url fn" rel="author">%2$s</a></span></div>',
                esc_url(get_author_posts_url(get_the_author_meta('ID'))),
                esc_html(get_the_author_meta('display_name', $author_id))
            );
        }

        $posted_on = '';
        // Posted on.
        if ($show_date) {
            $posted_on = '<div class="posted-on">'
                         . sprintf('<a href="%1$s" rel="bookmark">%2$s</a>', esc_url(get_permalink()), get_the_modified_date('F d,Y')) .
                         '</div>';
        }
        echo wp_kses(
            sprintf('%1$s  %2$s %3$s', $categories, $posted_on, $author), array(
                'div'  => array(
                    'class' => array('aaa'),
                ),
                'span' => array(
                    'class' => array(),
                ),
                'a'    => array(
                    'href'  => array(),
                    'rel'   => array(),
                    'class' => array(),
                    'style' => array(),
                ),
                'time' => array(
                    'datetime' => array(),
                    'class'    => array(),
                )
            )
        );

        if ($show_comment) { ?>
            <div class="meta-reply">
                <?php
                comments_popup_link(esc_html__('0 comments', 'aprin'), esc_html__('1 comment', 'aprin'), esc_html__('% comments', 'aprin'));
                ?>
            </div>
            <?php
        }

    }
}

if (!function_exists('aprin_get_allowed_html')) {
    function aprin_get_allowed_html() {
        return apply_filters(
            'aprin_allowed_html',
            array(
                'br'     => array(),
                'i'      => array(),
                'b'      => array(),
                'u'      => array(),
                'em'     => array(),
                'del'    => array(),
                'a'      => array(
                    'href'  => true,
                    'class' => true,
                    'title' => true,
                    'rel'   => true,
                ),
                'strong' => array(),
                'span'   => array(
                    'style' => true,
                    'class' => true,
                ),
            )
        );
    }
}

if (!function_exists('aprin_edit_post_link')) {
    /**
     * Display the edit link
     *
     * @since 2.5.0
     */
    function aprin_edit_post_link() {
        edit_post_link(
            sprintf(
                wp_kses(__('Edit <span class="screen-reader-text">%s</span>', 'aprin'),
                    array(
                        'span' => array(
                            'class' => array(),
                        ),
                    )
                ),
                get_the_title()
            ),
            '<div class="edit-link">',
            '</div>'
        );
    }
}

if (!function_exists('aprin_categories_link')) {
    /**
     * Prints HTML with meta information for the current cateogries
     */
    function aprin_categories_link() {

        // Get Categories for posts.
        $categories_list = get_the_category_list('');

        if ('post' === get_post_type() && $categories_list) {
            // Make sure there's more than one category before displaying.
            echo '<div class="categories-link"><span class="screen-reader-text">' . esc_html__('Categories', 'aprin') . '</span>' . $categories_list . '</div>';
        }
    }
}

if (!function_exists('aprin_post_taxonomy')) {
    /**
     * Display the post taxonomies
     *
     * @since 2.4.0
     */
    function aprin_post_taxonomy() {
        /* translators: used between list items, there is a space after the comma */

        /* translators: used between list items, there is a space after the comma */
        $tags_list = get_the_tag_list('', ' ');
        $heading   = apply_filters('aprin_social_heading', esc_html__('Share', 'aprin'));
        ?>
        <aside class="entry-taxonomy">
            <?php if ($tags_list) : ?>
                <div class="tags-links">
                    <span><?php echo esc_html(_n('Tag:', 'Tags:', count(get_the_tags()), 'aprin')); ?></span>
                    <?php printf('%s', $tags_list); ?>
                </div>
                <div class="aprin-social-share">
                    <a class="social-share"
                       href="<?php the_permalink(); ?>"
                       target="_blank" title="<?php esc_html_e('Share', 'aprin'); ?>">
                        <i class="aprin-icon-share"></i>
                    </a>
                    <?php echo '<div class="social-share-header"><span>' . esc_html($heading) . '</span></div>'; ?>
                </div>
            <?php endif;
            ?>
        </aside>
        <?php
    }
}

if (!function_exists('aprin_paging_nav')) {
    /**
     * Display navigation to next/previous set of posts when applicable.
     */
    function aprin_paging_nav() {
        global $wp_query;

        $args = array(
            'type'      => 'list',
            'next_text' => '<span>' . esc_html__('Next', 'aprin') . '</span> <i class="aprin-icon aprin-icon-angle-right"></i>',
            'prev_text' => '<i class="aprin-icon aprin-icon-angle-left"></i> <span>' . esc_html__('Prev', 'aprin') . '</span>',
        );

        the_posts_pagination($args);
    }
}

if (!function_exists('aprin_post_nav')) {
    /**
     * Display navigation to next/previous post when applicable.
     */
    function aprin_post_nav() {

        $prev_post      = get_previous_post();
        $next_post      = get_next_post();
        $args           = [];
        $thumbnail_prev = '';
        $thumbnail_next = '';

        if ($prev_post) {
            $thumbnail_prev = get_the_post_thumbnail($prev_post->ID, array(60, 60));
        };

        if ($next_post) {
            $thumbnail_next = get_the_post_thumbnail($next_post->ID, array(60, 60));
        };
        if ($next_post) {
            $args['next_text'] = '<span class="nav-content"><span class="reader-text">' . esc_html__('Next Post', 'aprin') . ' </span><span class="title">%title</span></span>' . $thumbnail_next;
        }
        if ($prev_post) {
            $args['prev_text'] = $thumbnail_prev . '<span class="nav-content"><span class="reader-text">' . esc_html__('Previous Post', 'aprin') . ' </span><span class="title">%title</span></span> ';
        }

        the_post_navigation($args);

    }
}

if (!function_exists('aprin_posted_on')) {
    /**
     * Prints HTML with meta information for the current post-date/time and author.
     *
     * @deprecated 2.4.0
     */
    function aprin_posted_on() {
        _deprecated_function('aprin_posted_on', '2.4.0');
    }
}

if (!function_exists('aprin_homepage_content')) {
    /**
     * Display homepage content
     * Hooked into the `homepage` action in the homepage template
     *
     * @return  void
     * @since  1.0.0
     */
    function aprin_homepage_content() {
        while (have_posts()) {
            the_post();

            get_template_part('content', 'homepage');

        } // end of the loop.
    }
}

if (!function_exists('aprin_get_sidebar')) {
    /**
     * Display aprin sidebar
     *
     * @uses get_sidebar()
     * @since 1.0.0
     */
    function aprin_get_sidebar() {
        get_sidebar();
    }
}

if (!function_exists('aprin_post_thumbnail')) {
    /**
     * Display post thumbnail
     *
     * @param string $size the post thumbnail size.
     *
     * @uses has_post_thumbnail()
     * @uses the_post_thumbnail
     * @var $size . thumbnail|medium|large|full|$custom
     * @since 1.5.0
     */
    function aprin_post_thumbnail($size = 'post-thumbnail', $showcate = false) {
        if (has_post_thumbnail()) :
            ?>
            <?php
            echo '<div class="post-thumbnail">';
            if ($showcate) { ?>
                <?php
                echo '<div class="posted-on">' . sprintf('<a href="%1$s" rel="bookmark">%2$s</a>', esc_url(get_permalink()), get_the_modified_date('d <b>M</b> Y')) . '</div>';
                ?>
            <?php }
            the_post_thumbnail($size ? $size : 'post-thumbnail');
            echo '</div>';
            ?>
        <?php
        endif;
    }
}

if (!function_exists('aprin_primary_navigation_wrapper')) {
    /**
     * The primary navigation wrapper
     */
    function aprin_primary_navigation_wrapper() {
        echo '<div class="aprin-primary-navigation"><div class="col-full">';
    }
}

if (!function_exists('aprin_primary_navigation_wrapper_close')) {
    /**
     * The primary navigation wrapper close
     */
    function aprin_primary_navigation_wrapper_close() {
        echo '</div></div>';
    }
}

if (!function_exists('aprin_header_container')) {
    /**
     * The header container
     */
    function aprin_header_container() {
        echo '<div class="col-full">';
    }
}

if (!function_exists('aprin_header_container_close')) {
    /**
     * The header container close
     */
    function aprin_header_container_close() {
        echo '</div>';
    }
}

if (!function_exists('aprin_header_custom_link')) {
    function aprin_header_custom_link() {
        echo aprin_get_theme_option('custom-link', '');
    }

}

if (!function_exists('aprin_header_contact_info')) {
    function aprin_header_contact_info() {
        echo aprin_get_theme_option('contact-info', '');
    }

}

if (!function_exists('aprin_header_account')) {
    function aprin_header_account() {

        if (!aprin_get_theme_option('show_header_account', true)) {
            return;
        }

        if (aprin_is_woocommerce_activated()) {
            $account_link = get_permalink(get_option('woocommerce_myaccount_page_id'));
        } else {
            $account_link = wp_login_url();
        }
        ?>
        <div class="site-header-account">
            <a href="<?php echo esc_url($account_link); ?>">
                <i class="aprin-icon-user-04"></i>
            </a>
            <div class="account-dropdown">

            </div>
        </div>
        <?php
    }

}

if (!function_exists('aprin_template_account_dropdown')) {
    function aprin_template_account_dropdown() {
        if (!aprin_get_theme_option('show_header_account', true)) {
            return;
        }
        ?>
        <div class="account-wrap d-none">
            <div class="account-inner <?php if (is_user_logged_in()): echo "dashboard"; endif; ?>">
                <?php if (!is_user_logged_in()) {
                    aprin_form_login();
                } else {
                    aprin_account_dropdown();
                }
                ?>
            </div>
        </div>
        <?php
    }
}

if (!function_exists('aprin_form_login')) {
    function aprin_form_login() {
        if (aprin_is_woocommerce_activated() && 'yes' === get_option('woocommerce_enable_myaccount_registration')) {
            $register_link = get_permalink(get_option('woocommerce_myaccount_page_id'));
        } else {
            $register_link = wp_registration_url();
        }
        ?>
        <div class="login-form-head">
            <span class="login-form-title"><?php esc_attr_e('Sign in', 'aprin') ?></span>
            <span class="pull-right">
                <a class="register-link" href="<?php echo esc_url($register_link); ?>"
                   title="<?php esc_attr_e('Register', 'aprin'); ?>"><?php esc_attr_e('Create an Account', 'aprin'); ?></a>
            </span>
        </div>
        <form class="aprin-login-form-ajax" data-toggle="validator">
            <p>
                <label><?php esc_attr_e('Username or email', 'aprin'); ?> <span class="required">*</span></label>
                <input name="username" type="text" required placeholder="<?php esc_attr_e('Username', 'aprin') ?>">
            </p>
            <p>
                <label><?php esc_attr_e('Password', 'aprin'); ?> <span class="required">*</span></label>
                <input name="password" type="password" required
                       placeholder="<?php esc_attr_e('Password', 'aprin') ?>">
            </p>
            <button type="submit" data-button-action
                    class="btn btn-primary btn-block w-100 mt-1"><?php esc_html_e('Login', 'aprin') ?></button>
            <input type="hidden" name="action" value="aprin_login">
            <?php wp_nonce_field('ajax-aprin-login-nonce', 'security-login'); ?>
        </form>
        <div class="login-form-bottom">
            <a href="<?php echo wp_lostpassword_url(get_permalink()); ?>" class="lostpass-link"
               title="<?php esc_attr_e('Lost your password?', 'aprin'); ?>"><?php esc_attr_e('Lost your password?', 'aprin'); ?></a>
        </div>
        <?php
    }
}

if (!function_exists('aprin_account_dropdown')) {
    function aprin_account_dropdown() { ?>
        <?php if (has_nav_menu('my-account')) : ?>
            <nav class="social-navigation" role="navigation" aria-label="<?php esc_attr_e('Dashboard', 'aprin'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'my-account',
                    'menu_class'     => 'account-links-menu',
                    'depth'          => 1,
                ));
                ?>
            </nav><!-- .social-navigation -->
        <?php else: ?>
            <ul class="account-dashboard">
                <?php if (aprin_is_woocommerce_activated()): ?>
                    <li>
                        <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>"
                           title="<?php esc_html_e('My account', 'aprin'); ?>"><?php esc_html_e('Dashboard', 'aprin'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url('orders')); ?>"
                           title="<?php esc_html_e('Orders', 'aprin'); ?>"><?php esc_html_e('Orders', 'aprin'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url('downloads')); ?>"
                           title="<?php esc_html_e('Downloads', 'aprin'); ?>"><?php esc_html_e('Downloads', 'aprin'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url('edit-address')); ?>"
                           title="<?php esc_html_e('Edit Address', 'aprin'); ?>"><?php esc_html_e('Edit Address', 'aprin'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url('edit-account')); ?>"
                           title="<?php esc_html_e('Account Details', 'aprin'); ?>"><?php esc_html_e('Account Details', 'aprin'); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo esc_url(get_dashboard_url(get_current_user_id())); ?>"
                           title="<?php esc_html_e('Dashboard', 'aprin'); ?>"><?php esc_html_e('Dashboard', 'aprin'); ?></a>
                    </li>
                <?php endif; ?>
                <li>
                    <a title="<?php esc_html_e('Log out', 'aprin'); ?>" class="tips"
                       href="<?php echo esc_url(wp_logout_url(home_url())); ?>"><?php esc_html_e('Log Out', 'aprin'); ?></a>
                </li>
            </ul>
        <?php endif;

    }
}

if (!function_exists('aprin_header_search_popup')) {
    function aprin_header_search_popup() {
        ?>
        <div class="site-search-popup">
            <div class="site-search-popup-wrap">
                <a href="#" class="site-search-popup-close">
                    <svg class="close-icon" xmlns="http://www.w3.org/2000/svg" width="23.691" height="22.723" viewBox="0 0 23.691 22.723">
                        <g transform="translate(-126.154 -143.139)">
                            <line x2="23" y2="22" transform="translate(126.5 143.5)" fill="none" stroke="CurrentColor" stroke-width="1"></line>
                            <path d="M0,22,23,0" transform="translate(126.5 143.5)" fill="none" stroke="CurrentColor" stroke-width="1"></path>
                        </g>
                    </svg>
                </a>
                <?php
                if (aprin_is_woocommerce_activated()) {
                    aprin_product_search();
                } else {
                    ?>
                    <div class="site-search">
                        <?php get_search_form(); ?>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <div class="site-search-popup-overlay"></div>
        <?php
    }
}

if (!function_exists('aprin_header_search_button')) {
    function aprin_header_search_button() {

        add_action('wp_footer', 'aprin_header_search_popup', 1);
        ?>
        <div class="site-header-search">
            <a href="#" class="button-search-popup"><i class="aprin-icon-search"></i></a>
        </div>
        <?php
    }
}


if (!function_exists('aprin_header_sticky')) {
    function aprin_header_sticky() {
        get_template_part('template-parts/header', 'sticky');
    }
}

if (!function_exists('aprin_mobile_nav')) {
    function aprin_mobile_nav() {
        if (isset(get_nav_menu_locations()['handheld'])) {
            ?>
            <div class="aprin-mobile-nav">
                <div class="menu-scroll-mobile">
                    <a href="#" class="mobile-nav-close"><i class="aprin-icon-times"></i></a>
                    <?php
                    aprin_mobile_navigation();
                    aprin_social();
                    ?>
                </div>
                <?php if (aprin_is_elementor_activated()) aprin_language_switcher_mobile(); ?>
            </div>
            <div class="aprin-overlay"></div>
            <?php
        }
    }
}

if (!function_exists('aprin_mobile_nav_button')) {
    function aprin_mobile_nav_button() {
        if (isset(get_nav_menu_locations()['handheld'])) {
            ?>
            <a href="#" class="menu-mobile-nav-button">
				<span
                        class="toggle-text screen-reader-text"><?php echo esc_attr(apply_filters('aprin_menu_toggle_text', esc_html__('Menu', 'aprin'))); ?></span>
                <div class="aprin-icon">
                    <span class="icon-1"></span>
                    <span class="icon-2"></span>
                    <span class="icon-3"></span>
                </div>
            </a>
            <?php
        }
    }
}

if (!function_exists('aprin_language_switcher')) {
    function aprin_language_switcher() {
        $languages = apply_filters('wpml_active_languages', []);
        if (aprin_is_wpml_activated() && count($languages) > 0) {
            ?>
            <div class="aprin-language-switcher">
                <ul class="menu">
                    <li class="item">
                        <div class="language-switcher-head">
                            <span class="title"><?php echo esc_html($languages[ICL_LANGUAGE_CODE]['translated_name']); ?></span>
                            <i aria-hidden="true" class="aprin-icon-angle-down"></i>
                        </div>
                        <ul class="sub-item">
                            <?php
                            foreach ($languages as $key => $language) {
                                if (ICL_LANGUAGE_CODE === $key) {
                                    continue;
                                }
                                ?>
                                <li>
                                    <a href="<?php echo esc_url($language['url']) ?>">
                                        <img width="18" height="12"
                                             src="<?php echo esc_url($language['country_flag_url']) ?>"
                                             alt="<?php esc_attr($language['default_locale']) ?>">
                                        <span><?php echo esc_html($language['translated_name']); ?></span>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>
                        </ul>
                    </li>
                </ul>
            </div>
            <?php
        }

    }
}

if (!function_exists('aprin_language_switcher_mobile')) {
    function aprin_language_switcher_mobile() {
        $languages = apply_filters('wpml_active_languages', []);
        if (aprin_is_wpml_activated() && count($languages) > 0) { ?>
            <div class="aprin-language-switcher-mobile">
                <ul class="menu">
                    <li class="item">
                        <div class="language-switcher-head">
                            <img src="<?php echo esc_url($languages[ICL_LANGUAGE_CODE]['country_flag_url']) ?>"
                                 alt="<?php esc_attr($languages[ICL_LANGUAGE_CODE]['default_locale']) ?>">
                        </div>
                    </li>
                    <?php foreach ($languages as $key => $language) {
                        if (ICL_LANGUAGE_CODE === $key) {
                            continue;
                        } ?>
                        <li class="item">
                            <div class="language-switcher-img">
                                <a href="<?php echo esc_url($language['url']) ?>">
                                    <img src="<?php echo esc_url($language['country_flag_url']) ?>"
                                         alt="<?php esc_attr($language['default_locale']) ?>">
                                </a>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <?php
        }
    }
}


if (!function_exists('aprin_footer_default')) {
    function aprin_footer_default() {
        get_template_part('template-parts/copyright');
    }
}

if (!function_exists('aprin_pingback_header')) {
    /**
     * Add a pingback url auto-discovery header for single posts, pages, or attachments.
     */
    function aprin_pingback_header() {
        if (is_singular() && pings_open()) {
            echo '<link rel="pingback" href="', esc_url(get_bloginfo('pingback_url')), '">';
        }
    }
}

if (!function_exists('aprin_update_comment_fields')) {
    function aprin_update_comment_fields($fields) {

        $commenter = wp_get_current_commenter();
        $req       = get_option('require_name_email');
        $aria_req  = $req ? "aria-required='true'" : '';

        $fields['author']
            = '<p class="comment-form-author">
			<input id="author" name="author" type="text" placeholder="' . esc_attr__('Your Name *', 'aprin') . '" value="' . esc_attr($commenter['comment_author']) .
              '" size="30" ' . $aria_req . ' />
		</p>';

        $fields['email']
            = '<p class="comment-form-email">
			<input id="email" name="email" type="email" placeholder="' . esc_attr__('Email Address *', 'aprin') . '" value="' . esc_attr($commenter['comment_author_email']) .
              '" size="30" ' . $aria_req . ' />
		</p>';

        $fields['url']
            = '<p class="comment-form-url">
			<input id="url" name="url" type="url"  placeholder="' . esc_attr__('Your Website', 'aprin') . '" value="' . esc_attr($commenter['comment_author_url']) .
              '" size="30" ' . $aria_req . ' />
			</p>';

        return $fields;
    }
}

add_filter('comment_form_default_fields', 'aprin_update_comment_fields');


function custom_comment_form_defaults($defaults) {
    $defaults['submit_button'] = '<button type="submit" id="%2$s" class="%3$s" value="%4$s"><span>%4$s</span></button>';
    return $defaults;
}

add_filter('comment_form_defaults', 'custom_comment_form_defaults');


if (!function_exists('aprin_update_comment_review_fields')) {
    function aprin_update_comment_review_fields($comment_form) {
        $commenter = wp_get_current_commenter();

        $name_email_required = (bool)get_option('require_name_email', 1);
        $fields              = array(
            'author' => array(
                'label'    => esc_html__('Name', 'aprin'),
                'type'     => 'text',
                'value'    => $commenter['comment_author'],
                'required' => $name_email_required,
            ),
            'email'  => array(
                'label'    => esc_html__('Email', 'aprin'),
                'type'     => 'email',
                'value'    => $commenter['comment_author_email'],
                'required' => $name_email_required,
            ),
            'url'    => array(
                'label' => esc_html__('Your Website', 'aprin'),
                'type'  => 'text',
                'value' => $commenter['comment_author_url'],
            ),
        );

        $comment_form['fields'] = array();

        foreach ($fields as $key => $field) {
            $field_html = '<p class="comment-form-' . esc_attr($key) . '">';

            $field_html .= '<input id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" type="' . esc_attr($field['type']) . '" value="' . esc_attr($field['value']) . '" size="30" ' . ($field['required'] ? 'required' : '') . ' placeholder="' . esc_html($field['label']) . ' *"' . ' />';

            $field_html .= '</p>';

            $comment_form['fields'][$key] = $field_html;
        }

        if (wc_review_ratings_enabled()) {
            $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating">' . esc_html__('Your rating', 'aprin') . (wc_review_ratings_required() ? '&nbsp;<span class="required">*</span>' : '') . '</label><select name="rating" id="rating" required>
						<option value="">' . esc_html__('Rate&hellip;', 'aprin') . '</option>
						<option value="5">' . esc_html__('Perfect', 'aprin') . '</option>
						<option value="4">' . esc_html__('Good', 'aprin') . '</option>
						<option value="3">' . esc_html__('Average', 'aprin') . '</option>
						<option value="2">' . esc_html__('Not that bad', 'aprin') . '</option>
						<option value="1">' . esc_html__('Very poor', 'aprin') . '</option>
					</select></div>';
        }
        $comment_form['comment_field'] .= '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" required placeholder="' . esc_html__('Your review *', 'aprin') . '"></textarea></p>';

        return $comment_form;
    }
}
add_filter('woocommerce_product_review_comment_form_args', 'aprin_update_comment_review_fields');


function aprin_replace_categories_list($output, $args) {
    if ($args['show_count'] = 1) {
        $pattern     = '#<li([^>]*)><a([^>]*)>(.*?)<\/a>\s*\(([0-9]*)\)\s*#i';  // removed ( and )
        $replacement = '<li$1><a$2><span class="cat-name">$3</span> <span class="cat-count">$4</span></a>';
        return preg_replace($pattern, $replacement, $output);
    }
    return $output;
}

add_filter('wp_list_categories', 'aprin_replace_categories_list', 10, 2);

function aprin_replace_archive_list($link_html, $url, $text, $format, $before, $after, $selected) {
    if ($format == 'html') {
        $pattern     = '#<li><a([^>]*)>(.*?)<\/a>&nbsp;\s*\(([0-9]*)\)\s*#i';  // removed ( and )
        $replacement = '<li><a$1><span class="archive-name">$2</span> <span class="archive-count">$3</span></a>';
        return preg_replace($pattern, $replacement, $link_html);
    }
    return $link_html;
}

add_filter('get_archives_link', 'aprin_replace_archive_list', 10, 7);


add_filter('bcn_breadcrumb_title', 'aprin_breadcrumb_title_swapper', 3, 10);
function aprin_breadcrumb_title_swapper($title, $type, $id) {
    if (in_array('home', $type)) {
        $title = esc_html__('Home', 'aprin');
    }
    return $title;
}

add_action('wp_footer', 'aprin_render_html_back_to_top');
function aprin_render_html_back_to_top() {
    echo sprintf('<a href="#" class="scrollup"><span class="scrollup-icon aprin-icon-long-arrow-up"></span><span class="scrollup-label">%s</span></a>',
        esc_html__('Top', 'aprin'));

}


function aprin_post_classe_related() {
    var_dump(get_the_ID());
//Get array of terms
    $terms = get_the_terms(get_the_ID(), 'product_tags', 'string');
//Pluck out the IDs to get an array of IDS
    $term_ids = wp_list_pluck($terms, 'term_id');

//Query posts with tax_query. Choose in 'IN' if want to query posts with any of the terms
//Chose 'AND' if you want to query for posts with all terms
    $second_query = new WP_Query(array(
        'post_type'           => 'products',
        'tax_query'           => array(
            array(
                'taxonomy' => 'product_tags',
                'field'    => 'id',
                'terms'    => $term_ids,
                'operator' => 'IN' //Or 'AND' or 'NOT IN'
            )),
        'posts_per_page'      => 3,
        'ignore_sticky_posts' => 1,
        'orderby'             => 'rand',
        'post__not_in'        => array(get_the_ID())
    ));

//Loop through posts and display...
    if ($second_query->have_posts()) {
        while ($second_query->have_posts()) : $second_query->the_post(); ?>
            <div class="single_related">
                <?php if (has_post_thumbnail()) { ?>
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"> <?php the_post_thumbnail('related_sm', array('alt' => get_the_title())); ?> </a>
                <?php } else { ?>
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                <?php } ?>
            </div>
        <?php endwhile;
        wp_reset_query();
    }
}

/**
 * Retrieves category list for a post in either HTML list or custom format.
 *
 * Generally used for quick, delimited (e.g. comma-separated) lists of categories,
 * as part of a post entry meta.
 *
 * For a more powerful, list-based function, see wp_list_categories().
 *
 * @param string $separator Optional. Separator between the categories. By default, the links are placed
 *                          in an unordered list. An empty string will result in the default behavior.
 * @param string $parents Optional. How to display the parents. Accepts 'multiple', 'single', or empty.
 *                          Default empty string.
 * @param int $post_id Optional. ID of the post to retrieve categories for. Defaults to the current post.
 * @return string Category list for a post.
 * @see wp_list_categories()
 *
 * @global WP_Rewrite $wp_rewrite WordPress rewrite component.
 *
 * @since 1.5.1
 *
 */
function aprin_get_the_category_list($separator = '', $parents = '', $post_id = false) {
    global $wp_rewrite;

    if (!is_object_in_taxonomy(get_post_type($post_id), 'category')) {
        /** This filter is documented in wp-includes/category-template.php */
        return apply_filters('the_category', '', $separator, $parents);
    }

    /**
     * Filters the categories before building the category list.
     *
     * @param WP_Term[] $categories An array of the post's categories.
     * @param int|false $post_id ID of the post to retrieve categories for.
     *                              When `false`, defaults to the current post in the loop.
     * @since 4.4.0
     *
     */
    $categories = apply_filters('the_category_list', get_the_category($post_id), $post_id);

    if (empty($categories)) {
        /** This filter is documented in wp-includes/category-template.php */
        return apply_filters('the_category', __('Uncategorized', 'aprin'), $separator, $parents);
    }

    $rel = (is_object($wp_rewrite) && $wp_rewrite->using_permalinks()) ? 'rel="category tag"' : 'rel="category"';

    $thelist = '';
    if ('' === $separator) {
        $thelist .= '<ul class="post-categories">';
        foreach ($categories as $category) {
            $thelist .= "\n\t<li>";
            $color   = get_term_meta($category->term_id, '_category_color', true);
            $color   = (!empty($color)) ? "color: #{$color}" : '';
            switch (strtolower($parents)) {
                case 'multiple':
                    if ($category->parent) {
                        $thelist .= get_category_parents($category->parent, true, $separator);
                    }
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '" ' . $rel . '>' . $category->name . '</a></li>';
                    break;
                case 'single':
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '"  ' . $rel . '>';
                    if ($category->parent) {
                        $thelist .= get_category_parents($category->parent, false, $separator);
                    }
                    $thelist .= $category->name . '</a></li>';
                    break;
                case '':
                default:
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '" ' . $rel . '>' . $category->name . '</a></li>';
            }
        }
        $thelist .= '</ul>';
    } else {
        $i = 0;
        foreach ($categories as $category) {
            if (0 < $i) {
                $thelist .= $separator;
            }
            $color = get_term_meta($category->term_id, '_category_color', true);
            $color = (!empty($color)) ? "color: #{$color}" : '';
            switch (strtolower($parents)) {
                case 'multiple':
                    if ($category->parent) {
                        $thelist .= get_category_parents($category->parent, true, $separator);
                    }
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '" ' . $rel . '>' . $category->name . '</a>';
                    break;
                case 'single':
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '" ' . $rel . '>';
                    if ($category->parent) {
                        $thelist .= get_category_parents($category->parent, false, $separator);
                    }
                    $thelist .= "$category->name</a>";
                    break;
                case '':
                default:
                    $thelist .= '<a style="' . $color . '" href="' . esc_url(get_category_link($category->term_id)) . '" ' . $rel . '>' . $category->name . '</a>';
            }
            ++$i;
        }
    }

    /**
     * Filters the category or list of categories.
     *
     * @param string $thelist List of categories for the current post.
     * @param string $separator Separator used between the categories.
     * @param string $parents How to display the category parents. Accepts 'multiple',
     *                          'single', or empty.
     * @since 1.2.0
     *
     */
    return apply_filters('the_category', $thelist, $separator, $parents);
}