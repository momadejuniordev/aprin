<?php

namespace Aprin;

use Aprin\Aprin_Custom_post_type;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class Aprin_Custom_Post_Type_Setting
 */
class Aprin_Custom_Post_Type_Setting extends Aprin_Custom_Post_Type {

    static $instance;

    public static function getInstance() {
        if (!isset(self::$instance) && !(self::$instance instanceof Aprin_Custom_Post_Type_Setting)) {
            self::$instance = new Aprin_Custom_Post_Type_Setting();
        }
        return self::$instance;
    }

    public function __construct() {
        parent::__construct();
        $this->setup();
    }

    public function getPosttypes() {
        return self::$posttypes;
    }

    public function setup() {
        $theme_support = array();
        foreach (self::$posttypes as $key => $posttype) {
            $theme_support[] = str_replace('aprin_', '', $key);
        }
        add_theme_support('custom-post-types', $theme_support);
    }
}

Aprin_Custom_Post_Type_Setting::getInstance();