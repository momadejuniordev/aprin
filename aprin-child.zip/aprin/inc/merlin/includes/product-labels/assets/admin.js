(function ($) {
    'use strict';
    var $aprin_apply = $('#aprin_apply');
    aprin_terms_select();
    aprin_conditional_init();
    aprin_conditional_select();
    aprin_labels_select();

    $('.color-picker').wpColorPicker();

    $aprin_apply.on('change', function() {
        var apply = $(this).val();
        var $terms = $('#aprin_terms');

        $('#aprin_configuration_combination').hide();
        $('#aprin_configuration_terms').hide();

        if (apply === '' || apply === 'none' || apply === 'all' || apply ===
            'sale' || apply === 'featured' || apply === 'bestselling' || apply ===
            'instock' || apply === 'outofstock' || apply === 'backorder') {
            return;
        }

        if (apply === 'combination') {
            $('#aprin_configuration_combination').show();
            return;
        }

        $('#aprin_configuration_terms').show();

        if ((typeof $terms.data(apply) === 'string' || $terms.data(apply) instanceof
            String) && $terms.data(apply) !== '') {
            $terms.val($terms.data(apply).split(',')).change();
        } else {
            $terms.val([]).change();
        }

        aprin_terms_select();
    });

    function aprin_terms_select() {
        var apply = $aprin_apply.val();
        var label = $aprin_apply.find(':selected').text().trim();

        $('#aprin_configuration_terms_label').html(label);

        $('#aprin_terms').selectWoo({
            ajax: {
                url: ajaxurl, dataType: 'json', delay: 250, data: function(params) {
                    return {
                        q: params.term,
                        action: 'aprin_search_term',
                        nonce: aprin_vars.nonce,
                        taxonomy: apply,
                    };
                }, processResults: function(data) {
                    var options = [];
                    if (data) {
                        $.each(data, function(index, text) {
                            options.push({id: text[0], text: text[1]});
                        });
                    }
                    return {
                        results: options,
                    };
                }, cache: true,
            }, minimumInputLength: 1,
        });
    }

    $(document).on('click touch', '.aprin_add_conditional', function(e) {
        e.preventDefault();

        var $this = $(this);

        $this.addClass('disabled');

        var data = {
            action: 'aprin_add_conditional', nonce: aprin_vars.nonce,
        };

        $.post(ajaxurl, data, function(response) {
            $('.aprin_conditionals').append(response);
            aprin_conditional_init();
            $this.removeClass('disabled');
        });
    });

    function aprin_conditional_init() {
        $('.aprin_conditional_apply').each(function() {
            var $this = $(this);
            var $value = $this.closest('.aprin_conditional').
            find('.aprin_conditional_value');
            var $select_wrap = $this.closest('.aprin_conditional').
            find('.aprin_conditional_select_wrap');
            var $select = $this.closest('.aprin_conditional').
            find('.aprin_conditional_select');
            var $compare = $this.closest('.aprin_conditional').
            find('.aprin_conditional_compare');
            var apply = $this.val();
            var compare = $compare.val();

            if (apply === 'sale' || apply === 'featured' || apply === 'bestselling' ||
                apply === 'instock' || apply === 'outofstock' || apply ===
                'backorder') {
                $compare.hide();
                $value.hide();
                $select_wrap.hide();
            } else {
                $compare.show();

                if (apply === 'price' || apply === 'rating' || apply === 'release') {
                    $select_wrap.hide();
                    $value.show();
                    $compare.find('.aprin_conditional_compare_price option').
                    prop('disabled', false);
                    $compare.find('.aprin_conditional_compare_terms option').
                    prop('disabled', true);

                    if (compare === 'is' || compare === 'is_not') {
                        $compare.val('equal').trigger('change');
                    }
                } else {
                    $select_wrap.show();
                    $value.hide();
                    $compare.find('.aprin_conditional_compare_price option').
                    prop('disabled', true);
                    $compare.find('.aprin_conditional_compare_terms option').
                    prop('disabled', false);

                    if (compare !== 'is' && compare !== 'is_not') {
                        $compare.val('is').trigger('change');
                    }
                }
            }

            if ($value.data(apply) !== '') {
                $value.val($value.data(apply));
            }

            if ((typeof $select.data(apply) === 'string' ||
                $select.data(apply) instanceof String) && $select.data(apply) !==
                '') {
                $select.val($select.data(apply).split(',')).change();
            } else {
                $select.val([]).change();
            }
        });
    }

    function aprin_conditional_select() {
        $('.aprin_conditional_select').each(function() {
            var $this = $(this);
            var apply = $this.closest('.aprin_conditional').
            find('.aprin_conditional_apply').
            val();

            $this.selectWoo({
                ajax: {
                    url: ajaxurl, dataType: 'json', delay: 250, data: function(params) {
                        return {
                            action: 'aprin_search_term',
                            nonce: aprin_vars.nonce,
                            q: params.term,
                            taxonomy: apply,
                        };
                    }, processResults: function(data) {
                        var options = [];
                        if (data) {
                            $.each(data, function(index, text) {
                                options.push({id: text[0], text: text[1]});
                            });
                        }
                        return {
                            results: options,
                        };
                    }, cache: true,
                }, minimumInputLength: 1,
            });
        });
    }

    function aprin_labels_select() {
        $('#aprin_labels').selectWoo({
            ajax: {
                url: ajaxurl, dataType: 'json', delay: 250, data: function(params) {
                    return {
                        action: 'aprin_search_labels',
                        nonce: aprin_vars.nonce,
                        q: params.term,
                    };
                }, processResults: function(data) {
                    var options = [];
                    if (data) {
                        $.each(data, function(index, text) {
                            options.push({id: text[0], text: text[1]});
                        });
                    }
                    return {
                        results: options,
                    };
                }, cache: true,
            }, minimumInputLength: 1, select: function(e) {
                var element = e.params.data.element;
                var $element = $(element);

                $(this).append($element);
                $(this).trigger('change');
            },
        });
    }

    $(document).on('change', '.aprin_conditional_apply', function() {
        aprin_conditional_init();
        aprin_conditional_select();
    });

    $(document).on('click touch', '.aprin_conditional_remove', function(e) {
        e.preventDefault();

        $(this).closest('.aprin_conditional').remove();
    });

})(jQuery);