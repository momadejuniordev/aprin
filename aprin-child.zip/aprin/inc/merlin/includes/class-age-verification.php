<?php

class Aprin_Age_Verification {
    private static $_instance = null;

    public static function instance() {
        if (!isset(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        add_action('customize_register', array($this, 'customize_register'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'), 10);
        add_action('wp_footer', array($this, 'aprin_avpublic_js'));
    }


    public function customize_register($wp_customize) {
        /**
         * Defining our own 'Display Options' section
         */
        $wp_customize->add_section(
            'aprin_display_options',
            array(
                'title'    => esc_attr__('Age Verification', 'aprin'),
                'priority' => 55,
            )
        );

        /* minAge */
        $wp_customize->add_setting(
            'aprin_minAge',
            array(
                'default'           => '18',
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_minAge',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Minimum age?', 'aprin'),
                'type'     => 'number',
                'priority' => 7,
            )
        );

        /* Add setting for background image uploader. */
        $wp_customize->add_setting('aprin_bgImage');

        /* Add control for background image uploader (actual uploader) */
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'aprin_bgImage',
                array(
                    'label'    => esc_attr__('Background image', 'aprin'),
                    'section'  => 'aprin_display_options',
                    'settings' => 'aprin_bgImage',
                    'priority' => 8
                )
            )
        );

        /* Add setting for logo uploader. */
        $wp_customize->add_setting('aprin_logo');

        /* Add control for logo uploader (actual uploader) */
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'aprin_logo',
                array(
                    'label'    => esc_attr__('Logo image', 'aprin'),
                    'section'  => 'aprin_display_options',
                    'settings' => 'aprin_logo',
                    'priority' => 9
                )
            )
        );

        /* title */
        $wp_customize->add_setting(
            'aprin_title',
            array(
                'default'           => esc_attr__('Are you over [age] years old?', 'aprin'),
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_title',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Title', 'aprin'),
                'type'     => 'text',
                'priority' => 10,
            )
        );

        /* description */
        $wp_customize->add_setting(
            'aprin_description',
            array(
                'default'           => esc_attr__('You must be of legal drinking age to buy our products. Age will be verified upon delivery through ID.', 'aprin'),
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_description',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Description', 'aprin'),
                'type'     => 'textarea',
                'priority' => 11,
            )
        );

        /* Yes button */
        $wp_customize->add_setting(
            'aprin_button_yes',
            array(
                'default'           => esc_attr__('Yes i am', 'aprin'),
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_button_yes',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Button yes text', 'aprin'),
                'type'     => 'text',
                'priority' => 14,
            )
        );

        /* No button */
        $wp_customize->add_setting(
            'aprin_button_no',
            array(
                'default'           => esc_attr__('No i am not', 'aprin'),
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_button_no',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Button no text', 'aprin'),
                'type'     => 'text',
                'priority' => 13,
            )
        );

        /* Success/Failure message display time */
        $wp_customize->add_setting(
            'aprin_message_display_time',
            array(
                'default'           => 2000,
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_message_display_time',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Message display time (milliseconds)', 'aprin'),
                'type'     => 'number',
                'priority' => 18,
            )
        );
        /* Success/Failure message display time */
        $wp_customize->add_setting(
            'aprin_cookie_days',
            array(
                'default'           => 30,
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_cookie_days',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Cookie (day)', 'aprin'),
                'type'     => 'number',
                'priority' => 20,
            )
        );

        /* Show or Hide Blog Description */
        $wp_customize->add_setting(
            'aprin_adminHide',
            array(
                'default'           => '',
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_adminHide',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Hide for admin users?', 'aprin'),
                'type'     => 'checkbox',
                'priority' => 99,
            )
        );

        /* Show or Hide Blog Description */
        $wp_customize->add_setting(
            'aprin_Enable',
            array(
                'default'           => '',
                'sanitize_callback' => 'aprin_sanitize_input',
                'transport'         => 'refresh',
            )
        );
        $wp_customize->add_control(
            'aprin_Enable',
            array(
                'section'  => 'aprin_display_options',
                'label'    => esc_attr__('Enable Age Verification', 'aprin'),
                'type'     => 'checkbox',
                'priority' => 99,
            )
        );
    }

    public function enqueue_scripts() {
        global $aprin_version;
        if ('1' == get_theme_mod('aprin_Enable')) {
            wp_enqueue_script('age-verification-cookie', get_template_directory_uri() . '/assets/js/frontend/js.cookie.js', array('jquery'), $aprin_version, false);
            wp_enqueue_script('age-verification', get_template_directory_uri() . '/assets/js/frontend/age-verification.js', array('jquery'), $aprin_version, false);
        }
    }

    function aprin_avpublic_js() {
        $landing = apply_filters('aprin_landing_id', '');
        // Empty redirect.
        $redirect_fail = '';

        // Set the redirect URL.
        $redirectOnFail = esc_url(apply_filters('aprin_avredirect_on_fail_link', $redirect_fail));

        // Add content before popup contents.
        $beforeContent = apply_filters('aprin_avbefore_popup_content', '');

        // Add content after popup contents.
        $afterContent = apply_filters('aprin_avafter_popup_content', '');

        // Add JavaScript codes to footer based on setting in the Customizer.

        if ('1' != get_theme_mod('aprin_Enable') || ('1' === get_theme_mod('aprin_adminHide') && current_user_can('administrator')) || $landing === get_queried_object_id()) {
            // Do nothing.
        } else { ?>
            <script type="text/javascript">
                (function ($) {
                    "use strict";
                    jQuery(document).ready(function () {
                        $.aprinageCheck({
                            "bgImage": '<?php echo get_theme_mod('aprin_bgImage', '') ?>',
                            "minAge": '<?php echo get_theme_mod('aprin_minAge', '18')?>',
                            "imgLogo": '<?php echo get_theme_mod('aprin_logo', '')?>',
                            "title": '<?php echo get_theme_mod('aprin_title', 'Are you over [age] years old?')?>',
                            "description": '<?php echo get_theme_mod('aprin_description', 'You must be of legal drinking age to buy our products. Age will be verified upon delivery through ID.')?>',
                            'btnYes': '<?php  echo get_theme_mod('aprin_button_yes', esc_attr__('Yes i am', 'aprin'))?>',
                            'btnNo': '<?php echo get_theme_mod('aprin_button_no', esc_attr__('No i am not', 'aprin'))?>',
                            "successTitle": '<?php echo esc_attr__('Success!', 'aprin')?>',
                            "successText": '<?php echo esc_attr__('You are now being redirected back to the site ...', 'aprin')?>',
                            "successMessage": '<?php echo get_theme_mod('aprin_success_message', 'show')?>',
                            "failTitle": '<?php echo esc_attr__('Sorry!', 'aprin')?>',
                            "failText": '<?php echo esc_attr__('You are not old enough to view the site ...', 'aprin')?>',
                            "messageTime": '<?php echo get_theme_mod('aprin_message_display_time', '2000')?>',
                            "cookieDays": '<?php echo get_theme_mod('aprin_cookie_days', '30')?>',
                            "redirectOnFail": '<?php echo $redirectOnFail?>',
                            "beforeContent": '<?php echo $beforeContent?>',
                            "afterContent": '<?php echo $afterContent?>'
                        });
                    });
                });
            </script>
            <?php
        } // end adminHide check.
    }

}

Aprin_Age_Verification::instance();