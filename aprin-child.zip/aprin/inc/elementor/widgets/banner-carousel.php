<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use Elementor\Group_Control_Box_Shadow;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Aprin\Elementor\Aprin_Base_Widgets;
use Elementor\Utils;

class Aprin_Elementor_Banner_carousel extends Aprin_Base_Widgets {

    /**
     * Get widget name.
     *
     * Retrieve testimonial widget name.
     *
     * @return string Widget name.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'aprin-banner-carousel';
    }

    /**
     * Get widget title.
     *
     * Retrieve testimonial widget title.
     *
     * @return string Widget title.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_title() {
        return esc_html__('Banner Carousel', 'aprin');
    }

    /**
     * Get widget icon.
     *
     * Retrieve testimonial widget icon.
     *
     * @return string Widget icon.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'eicon-image-rollover';
    }

    public function get_script_depends() {
        return ['aprin-elementor-banner-carousel'];
    }

    public function get_style_depends(): array {
        return [ 'e-swiper' ];
    }

    public function get_categories() {
        return array('aprin-addons');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_banner_carousel',
            [
                'label' => esc_html__('Item', 'aprin'),
            ]
        );
        $repeater = new Repeater();
        $repeater->add_control(
            'banner_subtitle',
            [
                'label' => esc_html__('Subtitle', 'aprin'),
                'default' => 'Designer',
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'banner_title',
            [
                'label' => esc_html__('Title', 'aprin'),
                'default' => 'John Doe',
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'banner_content',
            [
                'label'       => esc_html__('Content', 'aprin'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
                'label_block' => true,
                'rows'        => '10',
            ]
        );

        $repeater->add_control(
            'banner_carousel_image',
            [
                'label' => esc_html__('Choose Image', 'aprin'),
                'default' => [
                    'url' => Elementor\Utils::get_placeholder_image_src(),
                ],
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'bannercarousel',
            [
                'label' => esc_html__('Items', 'aprin'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ banner_title }}}',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'banner_carousel_image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `testimonial_image_size` and `testimonial_image_custom_dimension`.
                'default' => 'full',
                'separator' => 'none',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style_banner_image',
            [
                'label' => esc_html__('Image', 'aprin'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'width_banner_image',
            [
                'label'          => esc_html__('Width', 'aprin'),
                'type'           => Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'unit' => 'px',
                ],
                'size_units'     => ['%', 'px', 'vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'height_banner_image',
            [
                'label'          => esc_html__('Height', 'aprin'),
                'type'           => Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'unit' => 'px',
                ],
                'size_units'     => ['%', 'px', 'vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__('Border Radius', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'banner_image_padding',
            [
                'label' => esc_html__('Padding', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'banner_image_margin',
            [
                'label' => esc_html__('Margin', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_content_banner',
            [
                'label' => esc_html__('Content', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'width',
            [
                'label'      => esc_html__('Width', 'aprin'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    '%'  => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'banner_carousel_content_padding',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'banner_style_title',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => esc_html__('Title', 'aprin'),
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'title!'    => '',
                'name'      => 'banner_title_typography',
                'selector'  => '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-title',
            ]
        );
        $this->add_responsive_control(
            'banner_title_padding',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'banner_style_subtitle',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => esc_html__('SubTitle', 'aprin'),
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'title!'    => '',
                'name'      => 'banner_subtitle_typography',
                'selector'  => '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-subtitle',
            ]
        );
        $this->add_responsive_control(
            'banner_subtitle_padding',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'banner_style_content',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => esc_html__('Content', 'aprin'),
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'title!'    => '',
                'name'      => 'banner_content_typography',
                'selector'  => '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-description',
            ]
        );
        $this->add_responsive_control(
            'banner_content_padding',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'bannet_title_color',
            [
                'label' => esc_html__('Title Color', 'aprin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'bannet_subtitle_color',
            [
                'label' => esc_html__('SubTitle Color', 'aprin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'bannet_content_color',
            [
                'label' => esc_html__('Content Color', 'aprin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-banner-carousel-item-wrapper .elementor-banner-carousel-item .banner-caption .banner-description' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Carousel column
        $this->get_controls_column();
        // Carousel options
        $this->get_control_carousel();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        if (!empty($settings['bannercarousel']) && is_array($settings['bannercarousel'])) {
        $this->get_data_elementor_columns();
        $this->add_render_attribute('wrapper', 'class', 'elementor-banner-carousel-item-wrapper');
        $this->add_render_attribute('inner', 'class', 'elementor-banner-carousel-inner');

            // Item
        $this->add_render_attribute('item', 'class', 'elementor-banner-carousel-item');
        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); // WPCS: XSS ok. ?>>
            <div <?php $this->print_render_attribute_string('container'); ?>>
                <div <?php $this->print_render_attribute_string('inner'); // WPCS: XSS ok. ?>>
                    <?php foreach ($settings['bannercarousel'] as $item): ?>
                    <div <?php $this->print_render_attribute_string('item'); // WPCS: XSS ok. ?>>
                        <div class="banner-image">
                            <?php $this->render_image($settings, $item); ?>
                        </div>
                        <div class="banner-caption">
                            <div class="banner-subtitle"><?php echo esc_html($item['banner_subtitle']);?></div>
                            <div class="banner-title">
                                <?php echo esc_html($item['banner_title']);?>
                            </div>
                            <div class="banner-description"><?php echo esc_html($item['banner_content']);?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php $this->get_swiper_navigation(count($settings['bannercarousel'])); ?>
            </div>
        </div>
        <?php
        }
    }
    private function render_image($settings, $item)
    {
        if (!empty($item['banner_carousel_image']['url'])) :
            ?>
                <?php
                $item['banner_carousel_image_size'] = $settings['banner_carousel_image_size'];
                $item['banner_carousel_image_custom_dimension'] = $settings['banner_carousel_image_custom_dimension'];
                echo Group_Control_Image_Size::get_attachment_image_html($item, 'banner_carousel_image');
                ?>
        <?php
        endif;
    }
}
$widgets_manager->register(new Aprin_Elementor_Banner_carousel());

