<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use Elementor\Group_Control_Box_Shadow;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Aprin\Elementor\Aprin_Base_Widgets;
use Elementor\Utils;

class Aprin_Elementor_Product_Carousel extends Aprin_Base_Widgets {

    /**
     * Get widget name.
     *
     * Retrieve testimonial widget name.
     *
     * @return string Widget name.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'aprin-product-carousel';
    }

    /**
     * Get widget title.
     *
     * Retrieve testimonial widget title.
     *
     * @return string Widget title.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_title() {
        return esc_html__('Product Carousel', 'aprin');
    }

    /**
     * Get widget icon.
     *
     * Retrieve testimonial widget icon.
     *
     * @return string Widget icon.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'eicon-image-rollover';
    }

    public function get_script_depends() {
        return ['aprin-elementor-product-carousel'];
    }

    public function get_categories() {
        return array('aprin-addons');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_prodcut_carousel',
            [
                'label' => esc_html__('Item', 'aprin'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'limit',
            [
                'label'   => esc_html__('Posts Per Page', 'aprin'),
                'type'    => Controls_Manager::NUMBER,
                'default' => 1,
            ]
        );
        $repeater->add_control(
            'product_type',
            [
                'label'   => esc_html__('Product Type', 'aprin'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'newest',
                'options' => [
                    'newest'       => esc_html__('Newest Products', 'aprin'),
                    'on_sale'      => esc_html__('On Sale Products', 'aprin'),
                    'best_selling' => esc_html__('Best Selling', 'aprin'),
                    'top_rated'    => esc_html__('Top Rated', 'aprin'),
                    'featured'     => esc_html__('Featured Product', 'aprin'),
                    'ids'          => esc_html__('Product Name', 'aprin'),
                ],
            ]
        );
        $repeater->add_control(
            'product_ids',
            [
                'label'       => esc_html__('Products name', 'aprin'),
                'type'        => 'products',
                'label_block' => true,
                'multiple'    => true,
                'condition'   => [
                    'product_type' => 'ids'
                ]
            ]
        );
        $repeater->add_control(
            'product_carousel_image',
            [
                'label'      => esc_html__('Choose Image', 'aprin'),
                'default'    => [
                    'url' => Elementor\Utils::get_placeholder_image_src(),
                ],
                'type'       => Controls_Manager::MEDIA,
                'show_label' => false,
            ]
        );
        $repeater->add_control(
            'product_carousel_title',
            [
                'label'   => esc_html__('Title', 'aprin'),
                'default' => 'John Doe',
                'type'    => Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'product_carousel',
            [
                'label'       => esc_html__('Items', 'aprin'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ product_carousel_title }}}',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'product_carousel_image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `testimonial_image_size` and `testimonial_image_custom_dimension`.
                'default'   => 'full',
                'separator' => 'none',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_product_carousel_iamge_style',
            [
                'label' => esc_html__('Image', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'width_product_carousel_image',
            [
                'label'          => esc_html__('Width Image', 'aprin'),
                'type'           => Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => '%',
                ],
                'tablet_default' => [
                    'unit' => '%',
                ],
                'mobile_default' => [
                    'unit' => '%',
                ],
                'size_units'     => ['%', 'px', 'vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .elementor-product-carousel-item .product-carousel-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'product_carousel_image_padding',
            [
                'label' => esc_html__('Padding', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-product-carousel-item .product-carousel-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'product_carousel_image_margin',
            [
                'label' => esc_html__('Margin', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-product-carousel-item .product-carousel-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_product_carousel_style',
            [
                'label' => esc_html__('Product', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'width_product',
            [
                'label'          => esc_html__('Width Image', 'aprin'),
                'type'           => Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => '%',
                ],
                'tablet_default' => [
                    'unit' => '%',
                ],
                'mobile_default' => [
                    'unit' => '%',
                ],
                'size_units'     => ['%', 'px', 'vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .elementor-product-carousel-item .carousel-product' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'product_carousel_padding',
            [
                'label' => esc_html__('Padding', 'aprin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-product-carousel-item .carousel-product' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

    }
    protected function get_product_type($atts, $product_type) {
        switch ($product_type) {
            case 'featured':
                $atts['visibility'] = "featured";
                break;
            case 'on_sale':
                $atts['on_sale'] = true;
                break;
            case 'best_selling':
                $atts['best_selling'] = true;
                break;
            case 'top_rated':
                $atts['top_rated'] = true;
                break;
            default:
                break;
        }

        return $atts;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        if (!empty($settings['product_carousel']) && is_array($settings['product_carousel'])) {
            $this->add_render_attribute('wrapper', 'class', 'elementor-product-carousel-item-wrapper');
            $this->add_render_attribute('wrapper', 'class', 'aprin-swiper-product-carousel-wrapper swiper-1');
            $this->add_render_attribute('container', 'class', ['swiper', 'aprin-product-carousel-swiper']);
            $this->add_render_attribute('inner', 'class', 'swiper-wrapper');
            $this->add_render_attribute('item', 'class', 'swiper-slide elementor-product-carousel-item');
            ?>
            <div <?php $this->print_render_attribute_string('wrapper'); // WPCS: XSS ok. ?>>
                <div <?php $this->print_render_attribute_string('container'); ?>>
                    <div <?php $this->print_render_attribute_string('inner'); // WPCS: XSS ok. ?>>
                        <?php foreach ($settings['product_carousel'] as $item): ?>
                            <div <?php $this->print_render_attribute_string('item'); // WPCS: XSS ok. ?>>
                                <div class="carousel-product">
                                    <div class="product-item">
                                        <?php $this->woocommerce_default($item); ?>
                                    </div>
                                </div>
                                <div class="product-carousel-image">
                                    <div class="carousel-image">
                                        <?php $this->render_image($settings, $item); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="navigation">
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            <?php
        }
    }
    private function render_image($settings, $item)
    {
        if (!empty($item['product_carousel_image']['url'])) :
            ?>
            <div class="product-image">
                <?php
                $item['product_carousel_image_size'] = $settings['product_carousel_image_size'];
                $item['product_carousel_image_custom_dimension'] = $settings['product_carousel_image_custom_dimension'];
                echo Group_Control_Image_Size::get_attachment_image_html($item, 'product_carousel_image');
                ?>
            </div>
        <?php
        endif;
    }
    private function woocommerce_default($item) {
        $type  = 'products';
        $class = '';
        $atts  = [
            'limit'          => $item['limit'],
        ];
        $atts = $this->get_product_type($atts, $item['product_type']);
        $atts['show_time_sale'] = false;
        $atts['show_deal_sold'] = false;
        if (isset($atts['on_sale']) && wc_string_to_bool($atts['on_sale'])) {
            $type = 'sale_products';
            if ($item['show_time_sale']) {
                $atts['show_time_sale'] = true;
            }
            if ($item['show_deal_sold']) {
                $atts['show_deal_sold'] = true;
            }
        } elseif (isset($atts['best_selling']) && wc_string_to_bool($atts['best_selling'])) {
            $type = 'best_selling_products';
        } elseif (isset($atts['top_rated']) && wc_string_to_bool($atts['top_rated'])) {
            $type = 'top_rated_products';
        }
        if (isset($item['product_ids']) && !empty($item['product_ids']) && $item['product_type'] == 'ids') {
            $atts['ids'] = implode(',', $item['product_ids']);
        }
        $atts['class'] = $class;

        echo (new WC_Shortcode_Products($atts, $type))->get_content(); // WPCS: XSS ok
    }
}
$widgets_manager->register(new Aprin_Elementor_Product_Carousel());

