<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Aprin\Elementor\Aprin_Base_Widgets;


class Aprin_Elementor_Testimonials_Carousel extends Aprin_Base_Widgets {

    /**
     * Get widget name.
     *
     * Retrieve testimonial widget name.
     *
     * @return string Widget name.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'aprin-testimonials-carousel';
    }

    /**
     * Get widget title.
     *
     * Retrieve testimonial widget title.
     *
     * @return string Widget title.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_title() {
        return esc_html__('Aprin Testimonials Carousel', 'aprin');
    }

    /**
     * Get widget icon.
     *
     * Retrieve testimonial widget icon.
     *
     * @return string Widget icon.
     * @since  1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

    public function get_script_depends() {
        return ['aprin-elementor-testimonial-carousel'];
    }

    public function get_categories() {
        return array('aprin-addons');
    }

    /**
     * Register testimonial widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'section_testimonial_carousel',
            [
                'label' => esc_html__('Testimonials', 'aprin'),
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'testimonial_rating',
            [
                'label'   => esc_html__('Rating', 'aprin'),
                'default' => 5,
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    0 => esc_html__('Hidden', 'aprin'),
                    1 => esc_html__('Very poor', 'aprin'),
                    2 => esc_html__('Not that bad', 'aprin'),
                    3 => esc_html__('Average', 'aprin'),
                    4 => esc_html__('Good', 'aprin'),
                    5 => esc_html__('Perfect', 'aprin'),
                ]
            ]
        );
        $repeater->add_control(
            'testimonial_content',
            [
                'label'       => esc_html__('Content', 'aprin'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
                'label_block' => true,
                'rows'        => '10',
            ]
        );

        $repeater->add_control(
            'testimonial_name',
            [
                'label'   => esc_html__('Name', 'aprin'),
                'default' => 'John Doe',
                'type'    => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'testimonial_job',
            [
                'label'   => esc_html__('Job', 'aprin'),
                'default' => 'Design',
                'type'    => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'testimonial_image',
            [
                'label'      => esc_html__('Choose Image', 'aprin'),
                'type'       => Controls_Manager::MEDIA,
                'show_label' => false,
            ]
        );
        $repeater->add_control(
            'testimonial_rating_bottom',
            [
                'label'   => esc_html__('Rating', 'aprin'),
                'default' => 5,
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    0 => esc_html__('Hidden', 'aprin'),
                    1 => esc_html__('Very poor', 'aprin'),
                    2 => esc_html__('Not that bad', 'aprin'),
                    3 => esc_html__('Average', 'aprin'),
                    4 => esc_html__('Good', 'aprin'),
                    5 => esc_html__('Perfect', 'aprin'),
                ]
            ]
        );
        $repeater->add_control(
            'testimonial_content_bottom',
            [
                'label'       => esc_html__('Content', 'aprin'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
                'label_block' => true,
                'rows'        => '10',
            ]
        );

        $repeater->add_control(
            'testimonial_name_bottom',
            [
                'label'   => esc_html__('Name', 'aprin'),
                'default' => 'John Doe',
                'type'    => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'testimonial_job_bottom',
            [
                'label'   => esc_html__('Job', 'aprin'),
                'default' => 'Design',
                'type'    => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'testimonial_image_bottom',
            [
                'label'      => esc_html__('Choose Image', 'aprin'),
                'type'       => Controls_Manager::MEDIA,
                'show_label' => false,
            ]
        );
        $repeater->add_control(
            'testimonial_link',
            [
                'label'       => esc_html__('Link to', 'aprin'),
                'placeholder' => esc_html__('https://your-link.com', 'aprin'),
                'type'        => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'testimonials_carousel',
            [
                'label'       => esc_html__('Items', 'aprin'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ testimonial_name }}}',
            ]
        );
        $this->add_group_control(
            Elementor\Group_Control_Image_Size::get_type(),
            [
                'name'      => 'testimonial_image', 'testimonial_image_bottom',
                'default'   => 'full',
                'separator' => 'none',
            ]
        );

        $this->add_control(
            'view',
            [
                'label'   => esc_html__('View', 'aprin'),
                'type'    => Controls_Manager::HIDDEN,
                'default' => 'traditional',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_style_testimonial_carousel_wrapper',
            [
                'label' => esc_html__('Wrapper', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'padding_testimonial_carousel_wrapper',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .item-inner-top' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .item-inner-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'margin_testimonial_carousel_wrapper',
            [
                'label'      => esc_html__('Margin', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .item-inner-top' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .item-inner-bottom' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'background_hover',
            [
                'label'     => esc_html__('Background Hover', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'condition' => [
                    'show_hover_bottom' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}}.show-hover-bottom-yes .elementor-testimonial-item-wrapper .inner:after' => 'background-color: {{VALUE}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'color_testimonial_carousel_background',
            [
                'label'     => esc_html__('Background Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .inner' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'testimonial_box-shadow',
                'selector' => '{{WRAPPER}} .inner',
            ]
        );


        $this->add_responsive_control(
            'testimonial_alignment',
            [
                'label'       => esc_html__('Alignment Content', 'aprin'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
                    'left'   => [
                        'title' => esc_html__('Left', 'aprin'),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'aprin'),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'aprin'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'label_block' => false,
                'selectors'   => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .inner'                        => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .content'                        => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-caption .details' => 'text-align: {{VALUE}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-caption' => 'text-align: {{VALUE}}'

                ],
            ]
        );
        $this->add_responsive_control(
            'align_caption',
            [
                'label'     => esc_html__('Alignment Info ', 'aprin'),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start' => [
                        'title' => esc_html__('Left', 'aprin'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'aprin'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'   => [
                        'title' => esc_html__('Right', 'aprin'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'   => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonail-image-rating ' => 'justify-content: {{VALUE}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-caption' => 'justify-content: {{VALUE}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-caption .details' => 'justify-content: {{VALUE}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-caption .caption-top' => 'justify-content: {{VALUE}}'
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'        => 'wrapper_border',
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .inner',
                'separator'   => 'before',

            ]
        );

        $this->add_control(
            'wrapper_radius',
            [
                'label'      => esc_html__('Border Radius', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_style_testimonial_carousel_img',
            [
                'label' => esc_html__('Image', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'testimonial_carousel_width_img',
            [
                'label'      => esc_html__('Width', 'aprin'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'size_units' => ['px', '%', 'vw'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image img' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image-bottom img' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'testimonial_carousel_height_img',
            [
                'label'      => esc_html__('Height', 'aprin'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'size_units' => ['px', 'vh'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image img' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image-bottom img' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'testimonial_carousel_radius_img',
            [
                'label'      => esc_html__('Border Radius', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image-bottom img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'padding_testimonial_carousel_img',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'margin_testimonial_carousel_img',
            [
                'label'      => esc_html__('Margin', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-image-bottom' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__('Content', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'testimonial_carousel_content_color',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'content_content_color_hover',
            [
                'label'     => esc_html__('Color Hover', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .inner:hover .content' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'content_content_background_color',
            [
                'label'     => esc_html__('Background Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-content-text ' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'content_typography',
                'selector' => '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .content',
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label'      => esc_html__('Margin', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_padding',
            [
                'label'      => esc_html__('Padding', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .testimonial-content-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_testimonial_carousel_name',
            [
                'label' => esc_html__('Name', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'carousel_name_color',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name, {{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'carousel_name_color_hover',
            [
                'label'     => esc_html__('Color Hover', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name:hover, {{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name a:hover' => 'color: {{VALUE}};',

                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name',
            ]
        );

        $this->add_responsive_control(
            'name_margin',
            [
                'label'      => esc_html__('Margin', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
            ]
        );

        $this->end_controls_section();

        // Job.
        $this->start_controls_section(
            'section_style_testimonial_carousel_job',
            [
                'label' => esc_html__('Job', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'carousel_job_text_color',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .job' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'carousel_job_text_color_hover',
            [
                'label'     => esc_html__('Color Hover', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item:hover .job' => 'color: {{VALUE}};',
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'job_typography',
                'selector' => '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .job',
            ]
        );

        $this->end_controls_section();

        // rating
        $this->start_controls_section(
            'section_style_testimonial_carousel_rating',
            [
                'label' => esc_html__('Rating', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'carousel_rating_color',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-rating' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-rating-bottom' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'carousel_rating_spacing',
            [
                'label'      => esc_html__('Margin', 'aprin'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-testimonial-carousel-wrapper .elementor-testimonial-carousel-item .elementor-testimonial-rating-bottom' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

    }

    /**
     * Render testimonial widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        if (!empty($settings['testimonials_carousel']) && is_array($settings['testimonials_carousel'])) {
            $this->add_render_attribute('wrapper', 'class', 'elementor-testimonial-carousel-wrapper ');
            // Item
            $this->add_render_attribute('container', 'class', ['swiper', 'mySwiper' ]);

            $this->add_render_attribute('inner', 'class', 'swiper-wrapper');
            $this->add_render_attribute('item', 'class', 'swiper-slide elementor-testimonial-carousel-item ');
            ?>
            <div <?php $this->print_render_attribute_string('wrapper'); ?>>
                <div <?php $this->print_render_attribute_string('container'); ?>>
                    <div <?php $this->print_render_attribute_string('inner'); ?>>
                        <?php foreach ($settings['testimonials_carousel'] as $testimonials_carousel): ?>
                            <div  <?php $this->print_render_attribute_string('item'); ?>>
                                <div class="item-inner-top inner">
                                    <div class="testimonial-caption">
                                        <div class="caption-top">
                                            <?php $this->render_image($settings, $testimonials_carousel); ?>
                                        </div>
                                        <div <?php $this->print_render_attribute_string('details'); ?>>
                                            <?php
                                            $testimonial_name_html = $testimonials_carousel['testimonial_name'];
                                            if (!empty($testimonials_carousel['testimonial_link']['url'])) :
                                                $testimonial_name_html = '<a href="' . esc_url($testimonials_carousel['testimonial_link']['url']) . '">' . esc_html($testimonial_name_html) . '</a>';
                                            endif;
                                            printf('<span class="name">%s</span>', $testimonial_name_html);
                                            ?>
                                            <?php if ($testimonials_carousel['testimonial_job']): ?>
                                                <span class="job"><?php echo esc_html($testimonials_carousel['testimonial_job']); ?></span>
                                            <?php endif; ?>
                                            <?php $this->render_rating($testimonials_carousel); ?>
                                        </div>
                                    </div>
                                    <div class="testimonial-content-text">
                                        <?php if (!empty($testimonials_carousel['testimonial_content'])) : ?>
                                            <div class="content"><?php echo sprintf('%s', $testimonials_carousel['testimonial_content']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="item-inner-bottom inner">
                                    <div class="testimonial-caption">
                                        <div class="caption-top">
                                            <?php $this->render_image_bottom($settings, $testimonials_carousel); ?>
                                        </div>
                                        <div <?php $this->print_render_attribute_string('details'); ?>>
                                            <?php
                                            $testimonial_name_html = $testimonials_carousel['testimonial_name_bottom'];
                                            if (!empty($testimonials_carousel['testimonial_link']['url'])) :
                                                $testimonial_name_html = '<a href="' . esc_url($testimonials_carousel['testimonial_link']['url']) . '">' . esc_html($testimonial_name_html) . '</a>';
                                            endif;
                                            printf('<span class="name">%s</span>', $testimonial_name_html);
                                            ?>
                                            <?php if ($testimonials_carousel['testimonial_job_bottom']): ?>
                                                <span class="job"><?php echo esc_html($testimonials_carousel['testimonial_job_bottom']); ?></span>
                                            <?php endif; ?>
                                            <?php $this->render_rating_bottom($testimonials_carousel); ?>
                                        </div>
                                    </div>
                                    <div class="testimonial-content-text">
                                        <?php if (!empty($testimonials_carousel['testimonial_content_bottom'])) : ?>
                                            <div class="content"><?php echo sprintf('%s', $testimonials_carousel['testimonial_content_bottom']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php $this->get_swiper_navigation(count($settings['testimonials_carousel'])); ?>
                </div>
            </div>
            <?php
        }
    }

    private function render_image($settings, $testimonials_carousel) {
        if (!empty($testimonials_carousel['testimonial_image']['url'])) :
            ?>
            <div class="elementor-testimonial-image">
                <?php
                $testimonials_carousel['testimonial_image_size']             = $settings['testimonial_image_size'];
                $testimonials_carousel['testimonial_image_custom_dimension'] = $settings['testimonial_image_custom_dimension'];
                echo Group_Control_Image_Size::get_attachment_image_html($testimonials_carousel, 'testimonial_image');
                ?>
            </div>
        <?php
        endif;
    }
    private function render_image_bottom($settings, $testimonials_carousel) {
        if (!empty($testimonials_carousel['testimonial_image_bottom']['url'])) :
            ?>
            <div class="elementor-testimonial-image-bottom">
                <?php
                $testimonials_carousel['testimonial_image_size']             = $settings['testimonial_image_size'];
                $testimonials_carousel['testimonial_image_custom_dimension'] = $settings['testimonial_image_custom_dimension'];
                echo Group_Control_Image_Size::get_attachment_image_html($testimonials_carousel, 'testimonial_image_bottom');
                ?>
            </div>
        <?php
        endif;
    }

    private function render_rating($testimonials_carousel) {
        if ($testimonials_carousel['testimonial_rating'] && $testimonials_carousel['testimonial_rating'] > 0) {
            echo '<div class="elementor-testimonial-rating">';
            for ($i = 1; $i <= 5; $i++) {
                if ($i <= $testimonials_carousel['testimonial_rating']) {
                    echo '<i class="aprin-icon-rating active" aria-hidden="true"></i>';
                }
            }
            echo '</div>';
        }
    }
    private function render_rating_bottom($testimonials_carousel) {
        if ($testimonials_carousel['testimonial_rating_bottom'] && $testimonials_carousel['testimonial_rating_bottom'] > 0) {
            echo '<div class="elementor-testimonial-rating-bottom">';
            for ($i = 1; $i <= 5; $i++) {
                if ($i <= $testimonials_carousel['testimonial_rating_bottom']) {
                    echo '<i class="aprin-icon-rating active" aria-hidden="true"></i>';
                }
            }
            echo '</div>';
        }
    }
}

$widgets_manager->register(new Aprin_Elementor_Testimonials_Carousel());

