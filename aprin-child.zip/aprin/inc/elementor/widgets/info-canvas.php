<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;

class Aprin_Elementor_Info_Canvas extends Elementor\Widget_Base {

    public function get_name() {
        return 'aprin-info-canvas';
    }

    public function get_title() {
        return esc_html__('Aprin Info Canvas', 'aprin');
    }

    public function get_icon() {
        return 'eicon-nav-menu';
    }

    public function get_categories() {
        return ['aprin-addons'];
    }

    public function get_info() {
        global $post;

        $options[''] = esc_html__('Select Info', 'aprin');
        if (!aprin_is_elementor_activated()) {
            return;
        }
        $args = array(
            'post_type'      => 'elementor_library',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            's'              => 'Info',
            'order'          => 'ASC',
        );

        $query1 = new WP_Query($args);
        while ($query1->have_posts()) {
            $query1->the_post();
            $options[$post->post_name] = $post->post_title;
        }

        wp_reset_postdata();
        return $options;
    }

    protected function register_controls() {
        $this->start_controls_section(
            'info_sesion_content',
            [
                'label' => esc_html__('Content', 'aprin'),
            ]
        );

        $this->add_control(
            'info',
            [
                'label'   => esc_html__('Info Page', 'aprin'),
                'type'    => Controls_Manager::SELECT,
                'options' => $this->get_info(),
                'description' => esc_html__('The templates for Info Page will utilize the elementor library with the prefix name of "Info"', 'aprin'),
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label'   => esc_html__('Alignment', 'aprin'),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'left'  => [
                        'title' => esc_html__('Left', 'aprin'),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'aprin'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'right',
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label'      => esc_html__('Width', 'aprin'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min' => 300,
                        'max' => 600,
                    ],
                ],
                'selectors'  => [
                    'body .aprin-canvas-info' => '--e-global-info-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'icon_info_style',
            [
                'label' => esc_html__('Icon', 'aprin'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('color_tabs');

        $this->start_controls_tab('colors_normal',
            [
                'label' => esc_html__('Normal', 'aprin'),
            ]
        );

        $this->add_control(
            'info_color',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .aprin-info-button .aprin-icon > span' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .aprin-info-button .content' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .elementor-canvas-info-wrapper .aprin-info-button:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'layout_style',
            [
                'label'        => esc_html__('Layout Style', 'aprin'),
                'type'         => Controls_Manager::SELECT,
                'options'      => [
                    'layout-1' => esc_html__('Layout 1', 'aprin'),
                    'layout-2' => esc_html__('Layout 2', 'aprin'),
                    'layout-3' => esc_html__('Layout 3', 'aprin'),
                ],
                'default'      => 'layout-1',
                'prefix_class' => 'aprin-info-canvas-',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'colors_hover',
            [
                'label' => esc_html__('Hover', 'aprin'),
            ]
        );

        $this->add_control(
            '_menu_color_hover',
            [
                'label'     => esc_html__('Color', 'aprin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .aprin-info-button:hover .aprin-icon > span' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .aprin-info-button:hover .content' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .elementor-canvas-info-wrapper:hover .aprin-info-button:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    public function render_info() {
        $settings     = $this->get_settings_for_display();
        $slug         = $settings['info'];
        $queried_post = get_page_by_path($slug, OBJECT, 'elementor_library');
        ?>
        <div class="aprin-canvas-info aprin-canvas-info-<?php echo esc_attr($settings['align']) ?>">
            <a href="#" class="aprin-canvas-info-close"><i class="aprin-icon-close-01"></i></a>
            <?php if (isset($queried_post->ID)) {
                echo Elementor\Plugin::instance()->frontend->get_builder_content($queried_post->ID);
            } else {
                echo '<p>' . esc_html__('No Content', 'aprin') . '</p>';
            }
            ?>
        </div>

        <div class="aprin-info-overlay"></div>
        <?php
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $slug     = $settings['info'];
        add_action('wp_footer', array($this, 'render_info'));

        $this->add_render_attribute('wrapper', 'class', 'elementor-canvas-info-wrapper');

        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <a href="#" class="aprin-info-button">
                <div class="aprin-icon">
                    <span class="icon-1"></span>
                    <span class="icon-2"></span>
                    <span class="icon-3"></span>
                </div>
                <span class="content"><?php echo esc_html__('Menu', 'aprin'); ?></span>
            </a>
        </div>
        <?php
    }
}

$widgets_manager->register(new Aprin_Elementor_Info_Canvas());
