<?php


if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Aprin_Elementor')) :

    /**
     * The Aprin Elementor Integration class
     */
    class Aprin_Elementor {
        private $suffix;

        public function __construct() {
            $this->suffix = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';
            add_action('elementor/frontend/after_enqueue_scripts', [$this, 'register_auto_scripts_frontend']);
            add_action('elementor/init', array($this, 'add_category'));
            add_action('wp_enqueue_scripts', [$this, 'add_scripts'], 15);
            add_action('elementor/widgets/register', array($this, 'include_widgets'));
            add_action('elementor/frontend/after_enqueue_scripts', [$this, 'add_js']);

            // Custom Animation Scroll
            add_filter('elementor/controls/animations/additional_animations', [$this, 'add_animations_scroll']);
            add_filter('wp_enqueue_scripts', [$this, 'add_animations_scroll_style']);

            // Elementor Fix Noitice WooCommerce
            add_action('elementor/editor/before_enqueue_scripts', array($this, 'woocommerce_fix_notice'));

            // Backend
            add_action('elementor/editor/after_enqueue_styles', [$this, 'add_style_editor'], 99);

            // Add Icon Custom
            add_action('elementor/icons_manager/native', [$this, 'add_icons_native']);
            add_action('elementor/controls/controls_registered', [$this, 'add_icons']);

            // Add Breakpoints
            add_action('wp_enqueue_scripts', 'aprin_elementor_breakpoints', 9999);

            if (!aprin_is_elementor_pro_activated()) {
                require trailingslashit(get_template_directory()) . 'inc/elementor/class-section-sticky.php';
                if (is_admin()) {
                    add_action('manage_elementor_library_posts_columns', [$this, 'admin_columns_headers']);
                    add_action('manage_elementor_library_posts_custom_column', [$this, 'admin_columns_content'], 10, 2);
                }
            }

            add_filter('elementor/fonts/additional_fonts', [$this, 'additional_fonts']);

        }

        public function additional_fonts($fonts) {
            $fonts["Gabarito"] = 'system';
            return $fonts;
        }

        public function admin_columns_headers($defaults) {
            $defaults['shortcode'] = esc_html__('Shortcode', 'aprin');

            return $defaults;
        }

        public function admin_columns_content($column_name, $post_id) {
            if ('shortcode' === $column_name) {
                ob_start();
                ?>
                <input class="elementor-shortcode-input" type="text" readonly onfocus="this.select()" value="[hfe_template id='<?php echo esc_attr($post_id); ?>']"/>
                <?php
                ob_get_contents();
            }
        }

        public function add_js() {
            global $aprin_version;
            wp_enqueue_script('aprin-elementor-frontend', get_theme_file_uri('/assets/js/elementor-frontend.js'), [], $aprin_version);
            wp_enqueue_script('aprin-elementor-swiper-tabs-fix', get_theme_file_uri('/assets/js/elementor-swiper-tabs-fix.js'), [], $aprin_version);
        }

        public function add_style_editor() {
            global $aprin_version;
            wp_enqueue_style('aprin-icon', get_template_directory_uri() . '/assets/css/icons.css', '', $aprin_version);
        }

        public function add_scripts() {
            global $aprin_version;
            $suffix = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';
            wp_enqueue_style('aprin-elementor', get_template_directory_uri() . '/assets/css/elementor.css', '', $aprin_version);
            wp_style_add_data('aprin-elementor', 'rtl', 'replace');

            // Add Scripts
            wp_register_script('tweenmax', get_theme_file_uri('/assets/js/libs/TweenMax.min.js'), array('jquery'), '1.11.1');
            wp_register_script('parallaxmouse', get_theme_file_uri('/assets/js/libs/jquery-parallax.js'), array('jquery'), $aprin_version);
            if (aprin_elementor_check_type('animated-bg-parallax')) {
                wp_enqueue_script('tweenmax');
                wp_enqueue_script('jquery-panr', get_theme_file_uri('/assets/js/libs/jquery-panr' . $suffix . '.js'), array('jquery'), '0.0.1');
            }
        }

        public function register_auto_scripts_frontend() {
            // Add Scripts
            wp_register_script('aprin-elementor-animated-headline', get_theme_file_uri('/assets/js/elementor/animated-headline.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-banner-carousel', get_theme_file_uri('/assets/js/elementor/banner-carousel.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-brand', get_theme_file_uri('/assets/js/elementor/brand.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-countdown', get_theme_file_uri('/assets/js/elementor/countdown.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-custom-printing', get_theme_file_uri('/assets/js/elementor/custom-printing.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-gift-for', get_theme_file_uri('/assets/js/elementor/gift-for.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-header-carousel', get_theme_file_uri('/assets/js/elementor/header-carousel.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-image-carousel', get_theme_file_uri('/assets/js/elementor/image-carousel.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-image-gallery', get_theme_file_uri('/assets/js/elementor/image-gallery.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-image-hotspots', get_theme_file_uri('/assets/js/elementor/image-hotspots.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-link-showcase', get_theme_file_uri('/assets/js/elementor/link-showcase.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-nav-menu-vertical', get_theme_file_uri('/assets/js/elementor/nav-menu-vertical.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-posts-grid', get_theme_file_uri('/assets/js/elementor/posts-grid.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-product-carousel', get_theme_file_uri('/assets/js/elementor/product-carousel.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-product-categories', get_theme_file_uri('/assets/js/elementor/product-categories.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-products', get_theme_file_uri('/assets/js/elementor/products.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-slider-scrolling', get_theme_file_uri('/assets/js/elementor/slider-scrolling.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-team-box', get_theme_file_uri('/assets/js/elementor/team-box.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-testimonial', get_theme_file_uri('/assets/js/elementor/testimonial.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-testimonial-carousel', get_theme_file_uri('/assets/js/elementor/testimonial-carousel.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
            wp_register_script('aprin-elementor-video', get_theme_file_uri('/assets/js/elementor/video.js'), array('jquery','elementor-frontend'), APRIN_VERSION, true);
           
        }

        public function add_category() {
            Elementor\Plugin::instance()->elements_manager->add_category(
                'aprin-addons',
                array(
                    'title' => esc_html__('Aprin Addons', 'aprin'),
                    'icon'  => 'fa fa-plug',
                ), 1);
        }

        public function add_animations_scroll_style() {
            $animations = [
                'pavo-move-up'    => 'Move Up',
                'pavo-move-down'  => 'Move Down',
                'pavo-move-left'  => 'Move Left',
                'pavo-move-right' => 'Move Right',
                'pavo-flip'       => 'Flip',
                'pavo-helix'      => 'Helix',
                'pavo-scale-up'   => 'Scale',
                'pavo-am-popup'   => 'Popup',
            ];
            foreach ($animations as $animation => $name) {
                wp_deregister_style('e-animation-' . $animation);
                wp_register_style('e-animation-' . $animation, get_theme_file_uri('/assets/css/animations/' . $animation . '.css'), [], APRIN_VERSION);
            }
        }

        public function add_animations_scroll($animations) {
            $animations['Aprin Animation'] = [
                'pavo-move-up'    => 'Move Up',
                'pavo-move-down'  => 'Move Down',
                'pavo-move-left'  => 'Move Left',
                'pavo-move-right' => 'Move Right',
                'pavo-flip'       => 'Flip',
                'pavo-helix'      => 'Helix',
                'pavo-scale-up'   => 'Scale',
                'pavo-am-popup'   => 'Popup',
            ];

            return $animations;
        }

        /**
         * @param $widgets_manager Elementor\Widgets_Manager
         */
        public function include_widgets($widgets_manager) {
            require 'base_widgets.php';

            $files_custom = glob(get_theme_file_path('/inc/elementor/custom-widgets/*.php'));
            foreach ($files_custom as $file) {
                if (file_exists($file)) {
                    require_once $file;
                }
            }

            $files = glob(get_theme_file_path('/inc/elementor/widgets/*.php'));
            foreach ($files as $file) {
                if (file_exists($file)) {
                    require_once $file;
                }
            }
        }

        public function woocommerce_fix_notice() {
            if (aprin_is_woocommerce_activated()) {
                remove_action('woocommerce_cart_is_empty', 'woocommerce_output_all_notices', 5);
                remove_action('woocommerce_shortcode_before_product_cat_loop', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_before_single_product', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_before_cart', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_before_checkout_form', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_account_content', 'woocommerce_output_all_notices', 10);
                remove_action('woocommerce_before_customer_login_form', 'woocommerce_output_all_notices', 10);
            }
        }

        public function add_icons( $manager ) {
            $new_icons = json_decode( '{"aprin-icon-arrow-down-right":"arrow-down-right","aprin-icon-hexagon":"hexagon","aprin-icon-play":"play","aprin-icon-360":"360","aprin-icon-add-line":"add-line","aprin-icon-add-to-cart":"add-to-cart","aprin-icon-angle-down":"angle-down","aprin-icon-angle-left":"angle-left","aprin-icon-angle-right":"angle-right","aprin-icon-angle-up":"angle-up","aprin-icon-arrow-alt-circle-down":"arrow-alt-circle-down","aprin-icon-arrow-alt-circle-left":"arrow-alt-circle-left","aprin-icon-arrow-alt-circle-right":"arrow-alt-circle-right","aprin-icon-arrow-alt-circle-up":"arrow-alt-circle-up","aprin-icon-arrow-alt-down":"arrow-alt-down","aprin-icon-arrow-alt-from-bottom":"arrow-alt-from-bottom","aprin-icon-arrow-alt-from-left":"arrow-alt-from-left","aprin-icon-arrow-alt-from-right":"arrow-alt-from-right","aprin-icon-arrow-alt-from-top":"arrow-alt-from-top","aprin-icon-arrow-alt-left":"arrow-alt-left","aprin-icon-arrow-alt-right":"arrow-alt-right","aprin-icon-arrow-alt-square-down":"arrow-alt-square-down","aprin-icon-arrow-alt-square-left":"arrow-alt-square-left","aprin-icon-arrow-alt-square-right":"arrow-alt-square-right","aprin-icon-arrow-alt-square-up":"arrow-alt-square-up","aprin-icon-arrow-alt-to-bottom":"arrow-alt-to-bottom","aprin-icon-arrow-alt-to-left":"arrow-alt-to-left","aprin-icon-arrow-alt-to-right":"arrow-alt-to-right","aprin-icon-arrow-alt-to-top":"arrow-alt-to-top","aprin-icon-arrow-alt-up":"arrow-alt-up","aprin-icon-arrow-circle-down":"arrow-circle-down","aprin-icon-arrow-circle-left":"arrow-circle-left","aprin-icon-arrow-circle-right":"arrow-circle-right","aprin-icon-arrow-circle-up":"arrow-circle-up","aprin-icon-arrow-down":"arrow-down","aprin-icon-arrow-from-bottom":"arrow-from-bottom","aprin-icon-arrow-from-left":"arrow-from-left","aprin-icon-arrow-from-right":"arrow-from-right","aprin-icon-arrow-from-top":"arrow-from-top","aprin-icon-arrow-left":"arrow-left","aprin-icon-arrow-right":"arrow-right","aprin-icon-arrow-square-down":"arrow-square-down","aprin-icon-arrow-square-left":"arrow-square-left","aprin-icon-arrow-square-right":"arrow-square-right","aprin-icon-arrow-square-up":"arrow-square-up","aprin-icon-arrow-to-bottom":"arrow-to-bottom","aprin-icon-arrow-to-left":"arrow-to-left","aprin-icon-arrow-to-right":"arrow-to-right","aprin-icon-arrow-to-top":"arrow-to-top","aprin-icon-arrow-up-right":"arrow-up-right","aprin-icon-arrow-up":"arrow-up","aprin-icon-arrows-alt-h":"arrows-alt-h","aprin-icon-arrows-alt-v":"arrows-alt-v","aprin-icon-arrows-alt":"arrows-alt","aprin-icon-arrows-h":"arrows-h","aprin-icon-arrows-v":"arrows-v","aprin-icon-arrows":"arrows","aprin-icon-bag-02":"bag-02","aprin-icon-bow-arrow":"bow-arrow","aprin-icon-bullseye-arrow":"bullseye-arrow","aprin-icon-calendar":"calendar","aprin-icon-caret-circle-down":"caret-circle-down","aprin-icon-caret-circle-left":"caret-circle-left","aprin-icon-caret-circle-right":"caret-circle-right","aprin-icon-caret-circle-up":"caret-circle-up","aprin-icon-caret-down":"caret-down","aprin-icon-caret-left":"caret-left","aprin-icon-caret-right":"caret-right","aprin-icon-caret-square-down":"caret-square-down","aprin-icon-caret-square-left":"caret-square-left","aprin-icon-caret-square-right":"caret-square-right","aprin-icon-caret-square-up":"caret-square-up","aprin-icon-caret-up":"caret-up","aprin-icon-cart-arrow-down":"cart-arrow-down","aprin-icon-cart-empty":"cart-empty","aprin-icon-chat":"chat","aprin-icon-check-02":"check-02","aprin-icon-check-circle":"check-circle","aprin-icon-check-double":"check-double","aprin-icon-check-fill":"check-fill","aprin-icon-check-square":"check-square","aprin-icon-checkbox-circle-fill":"checkbox-circle-fill","aprin-icon-chevron-double-down":"chevron-double-down","aprin-icon-chevron-double-left":"chevron-double-left","aprin-icon-chevron-double-right":"chevron-double-right","aprin-icon-chevron-double-up":"chevron-double-up","aprin-icon-chevron-down":"chevron-down","aprin-icon-chevron-left":"chevron-left","aprin-icon-chevron-right":"chevron-right","aprin-icon-chevron-selector-vertical":"chevron-selector-vertical","aprin-icon-chevron-square-down":"chevron-square-down","aprin-icon-chevron-up":"chevron-up","aprin-icon-close-01":"close-01","aprin-icon-close":"close","aprin-icon-cloud-download-alt":"cloud-download-alt","aprin-icon-comment-info":"comment-info","aprin-icon-compare-1":"compare-1","aprin-icon-compare":"compare","aprin-icon-compress-arrows-alt":"compress-arrows-alt","aprin-icon-credit-card":"credit-card","aprin-icon-dot-circle":"dot-circle","aprin-icon-dotfour":"dotfour","aprin-icon-double-quotes-r":"double-quotes-r","aprin-icon-double-quotes":"double-quotes","aprin-icon-edit":"edit","aprin-icon-email-01":"email-01","aprin-icon-envelope-1":"envelope-1","aprin-icon-envelope":"envelope","aprin-icon-equalizer-line":"equalizer-line","aprin-icon-expand-arrows-alt":"expand-arrows-alt","aprin-icon-expand-arrows":"expand-arrows","aprin-icon-eye-dropper":"eye-dropper","aprin-icon-eye-evil":"eye-evil","aprin-icon-eye-slash":"eye-slash","aprin-icon-eye":"eye","aprin-icon-file-alt":"file-alt","aprin-icon-file-archive":"file-archive","aprin-icon-filter":"filter","aprin-icon-free-shipping":"free-shipping","aprin-icon-frown-open":"frown-open","aprin-icon-frown":"frown","aprin-icon-gift-card":"gift-card","aprin-icon-gift":"gift","aprin-icon-gifts":"gifts","aprin-icon-gmail-01":"gmail-01","aprin-icon-heart":"heart","aprin-icon-home":"home","aprin-icon-info-circle":"info-circle","aprin-icon-layout-grid":"layout-grid","aprin-icon-layout-list":"layout-list","aprin-icon-liquid":"liquid","aprin-icon-location-02":"location-02","aprin-icon-location-arrow":"location-arrow","aprin-icon-locationn":"locationn","aprin-icon-long-arrow-alt-down":"long-arrow-alt-down","aprin-icon-long-arrow-alt-left":"long-arrow-alt-left","aprin-icon-long-arrow-alt-right":"long-arrow-alt-right","aprin-icon-long-arrow-alt-up":"long-arrow-alt-up","aprin-icon-long-arrow-down":"long-arrow-down","aprin-icon-long-arrow-left":"long-arrow-left","aprin-icon-long-arrow-right":"long-arrow-right","aprin-icon-long-arrow-up":"long-arrow-up","aprin-icon-meh-blank":"meh-blank","aprin-icon-meh-rolling-eyes":"meh-rolling-eyes","aprin-icon-meh":"meh","aprin-icon-minus-circle":"minus-circle","aprin-icon-minus":"minus","aprin-icon-money-check-alt":"money-check-alt","aprin-icon-overlap":"overlap","aprin-icon-phone-03":"phone-03","aprin-icon-phone":"phone","aprin-icon-pin-1":"pin-1","aprin-icon-pinterest-02":"pinterest-02","aprin-icon-plane-1":"plane-1","aprin-icon-plane-arrival":"plane-arrival","aprin-icon-play-fill":"play-fill","aprin-icon-plus-circle":"plus-circle","aprin-icon-plus":"plus","aprin-icon-quickview-1":"quickview-1","aprin-icon-quickview":"quickview","aprin-icon-rating":"rating","aprin-icon-repeat":"repeat","aprin-icon-reply-line":"reply-line","aprin-icon-reply":"reply","aprin-icon-search-01":"search-01","aprin-icon-search-plus":"search-plus","aprin-icon-search":"search","aprin-icon-share-all":"share-all","aprin-icon-share":"share","aprin-icon-shopping-bag-2":"shopping-bag-2","aprin-icon-shopping-bag":"shopping-bag","aprin-icon-shopping-basket":"shopping-basket","aprin-icon-shopping-cart":"shopping-cart","aprin-icon-sign-out-alt":"sign-out-alt","aprin-icon-smile":"smile","aprin-icon-spinner-third":"spinner-third","aprin-icon-spinner":"spinner","aprin-icon-square-full":"square-full","aprin-icon-star-1":"star-1","aprin-icon-star-exclamation":"star-exclamation","aprin-icon-star-half-alt":"star-half-alt","aprin-icon-star-half":"star-half","aprin-icon-star":"star","aprin-icon-stars":"stars","aprin-icon-sync-alt":"sync-alt","aprin-icon-sync":"sync","aprin-icon-tachometer-alt":"tachometer-alt","aprin-icon-time-1":"time-1","aprin-icon-times-circle":"times-circle","aprin-icon-times":"times","aprin-icon-truck":"truck","aprin-icon-twiter-02":"twiter-02","aprin-icon-user-01":"user-01","aprin-icon-user-03":"user-03","aprin-icon-user-04":"user-04","aprin-icon-wishlist-1":"wishlist-1","aprin-icon-wishlist":"wishlist","aprin-icon-World":"World","aprin-icon-youtube-02":"youtube-02","aprin-icon-500px":"500px","aprin-icon-accessible-icon":"accessible-icon","aprin-icon-accusoft":"accusoft","aprin-icon-acquisitions-incorporated":"acquisitions-incorporated","aprin-icon-adn":"adn","aprin-icon-adversal":"adversal","aprin-icon-affiliatetheme":"affiliatetheme","aprin-icon-airbnb":"airbnb","aprin-icon-algolia":"algolia","aprin-icon-alipay":"alipay","aprin-icon-amazon-pay":"amazon-pay","aprin-icon-amazon":"amazon","aprin-icon-amilia":"amilia","aprin-icon-android":"android","aprin-icon-angellist":"angellist","aprin-icon-angrycreative":"angrycreative","aprin-icon-angular":"angular","aprin-icon-app-store-ios":"app-store-ios","aprin-icon-app-store":"app-store","aprin-icon-apper":"apper","aprin-icon-apple-pay":"apple-pay","aprin-icon-apple":"apple","aprin-icon-artstation":"artstation","aprin-icon-asymmetrik":"asymmetrik","aprin-icon-atlassian":"atlassian","aprin-icon-audible":"audible","aprin-icon-autoprefixer":"autoprefixer","aprin-icon-avianex":"avianex","aprin-icon-aviato":"aviato","aprin-icon-aws":"aws","aprin-icon-bandcamp":"bandcamp","aprin-icon-battle-net":"battle-net","aprin-icon-behance-square":"behance-square","aprin-icon-behance":"behance","aprin-icon-bimobject":"bimobject","aprin-icon-bitbucket":"bitbucket","aprin-icon-bitcoin":"bitcoin","aprin-icon-bity":"bity","aprin-icon-black-tie":"black-tie","aprin-icon-blackberry":"blackberry","aprin-icon-blogger-b":"blogger-b","aprin-icon-blogger":"blogger","aprin-icon-bluetooth-b":"bluetooth-b","aprin-icon-bluetooth":"bluetooth","aprin-icon-bootstrap":"bootstrap","aprin-icon-btc":"btc","aprin-icon-buffer":"buffer","aprin-icon-buromobelexperte":"buromobelexperte","aprin-icon-buy-n-large":"buy-n-large","aprin-icon-buysellads":"buysellads","aprin-icon-canadian-maple-leaf":"canadian-maple-leaf","aprin-icon-cc-amazon-pay":"cc-amazon-pay","aprin-icon-cc-amex":"cc-amex","aprin-icon-cc-apple-pay":"cc-apple-pay","aprin-icon-cc-diners-club":"cc-diners-club","aprin-icon-cc-discover":"cc-discover","aprin-icon-cc-jcb":"cc-jcb","aprin-icon-cc-mastercard":"cc-mastercard","aprin-icon-cc-paypal":"cc-paypal","aprin-icon-cc-stripe":"cc-stripe","aprin-icon-cc-visa":"cc-visa","aprin-icon-centercode":"centercode","aprin-icon-centos":"centos","aprin-icon-chrome":"chrome","aprin-icon-chromecast":"chromecast","aprin-icon-cloudflare":"cloudflare","aprin-icon-cloudscale":"cloudscale","aprin-icon-cloudsmith":"cloudsmith","aprin-icon-cloudversify":"cloudversify","aprin-icon-codepen":"codepen","aprin-icon-codiepie":"codiepie","aprin-icon-confluence":"confluence","aprin-icon-connectdevelop":"connectdevelop","aprin-icon-contao":"contao","aprin-icon-cotton-bureau":"cotton-bureau","aprin-icon-cpanel":"cpanel","aprin-icon-creative-commons-by":"creative-commons-by","aprin-icon-creative-commons-nc-eu":"creative-commons-nc-eu","aprin-icon-creative-commons-nc-jp":"creative-commons-nc-jp","aprin-icon-creative-commons-nc":"creative-commons-nc","aprin-icon-creative-commons-nd":"creative-commons-nd","aprin-icon-creative-commons-pd-alt":"creative-commons-pd-alt","aprin-icon-creative-commons-pd":"creative-commons-pd","aprin-icon-creative-commons-remix":"creative-commons-remix","aprin-icon-creative-commons-sa":"creative-commons-sa","aprin-icon-creative-commons-sampling-plus":"creative-commons-sampling-plus","aprin-icon-creative-commons-sampling":"creative-commons-sampling","aprin-icon-creative-commons-share":"creative-commons-share","aprin-icon-creative-commons-zero":"creative-commons-zero","aprin-icon-creative-commons":"creative-commons","aprin-icon-critical-role":"critical-role","aprin-icon-css3-alt":"css3-alt","aprin-icon-css3":"css3","aprin-icon-cuttlefish":"cuttlefish","aprin-icon-d-and-d-beyond":"d-and-d-beyond","aprin-icon-d-and-d":"d-and-d","aprin-icon-dailymotion":"dailymotion","aprin-icon-dashcube":"dashcube","aprin-icon-deezer":"deezer","aprin-icon-delicious":"delicious","aprin-icon-deploydog":"deploydog","aprin-icon-deskpro":"deskpro","aprin-icon-dev":"dev","aprin-icon-deviantart":"deviantart","aprin-icon-dhl":"dhl","aprin-icon-diaspora":"diaspora","aprin-icon-digg":"digg","aprin-icon-digital-ocean":"digital-ocean","aprin-icon-discord":"discord","aprin-icon-discourse":"discourse","aprin-icon-dochub":"dochub","aprin-icon-docker":"docker","aprin-icon-draft2digital":"draft2digital","aprin-icon-dribbble-square":"dribbble-square","aprin-icon-dribbble":"dribbble","aprin-icon-dropbox":"dropbox","aprin-icon-drupal":"drupal","aprin-icon-dyalog":"dyalog","aprin-icon-earlybirds":"earlybirds","aprin-icon-ebay":"ebay","aprin-icon-edge-legacy":"edge-legacy","aprin-icon-edge":"edge","aprin-icon-elementor":"elementor","aprin-icon-ello":"ello","aprin-icon-ember":"ember","aprin-icon-empire":"empire","aprin-icon-envira":"envira","aprin-icon-erlang":"erlang","aprin-icon-ethereum":"ethereum","aprin-icon-etsy":"etsy","aprin-icon-evernote":"evernote","aprin-icon-expeditedssl":"expeditedssl","aprin-icon-facebook-f":"facebook-f","aprin-icon-facebook-messenger":"facebook-messenger","aprin-icon-facebook-square":"facebook-square","aprin-icon-facebook":"facebook","aprin-icon-fantasy-flight-games":"fantasy-flight-games","aprin-icon-fedex":"fedex","aprin-icon-fedora":"fedora","aprin-icon-figma":"figma","aprin-icon-firefox-browser":"firefox-browser","aprin-icon-firefox":"firefox","aprin-icon-first-order-alt":"first-order-alt","aprin-icon-first-order":"first-order","aprin-icon-firstdraft":"firstdraft","aprin-icon-flickr":"flickr","aprin-icon-flipboard":"flipboard","aprin-icon-fly":"fly","aprin-icon-font-awesome":"font-awesome","aprin-icon-fonticons-fi":"fonticons-fi","aprin-icon-fonticons":"fonticons","aprin-icon-fort-awesome-alt":"fort-awesome-alt","aprin-icon-fort-awesome":"fort-awesome","aprin-icon-forumbee":"forumbee","aprin-icon-foursquare":"foursquare","aprin-icon-free-code-camp":"free-code-camp","aprin-icon-freebsd":"freebsd","aprin-icon-fulcrum":"fulcrum","aprin-icon-galactic-republic":"galactic-republic","aprin-icon-galactic-senate":"galactic-senate","aprin-icon-get-pocket":"get-pocket","aprin-icon-gg-circle":"gg-circle","aprin-icon-gg":"gg","aprin-icon-git-alt":"git-alt","aprin-icon-git-square":"git-square","aprin-icon-git":"git","aprin-icon-github-alt":"github-alt","aprin-icon-github-square":"github-square","aprin-icon-github":"github","aprin-icon-gitkraken":"gitkraken","aprin-icon-gitlab":"gitlab","aprin-icon-gitter":"gitter","aprin-icon-glide-g":"glide-g","aprin-icon-glide":"glide","aprin-icon-gofore":"gofore","aprin-icon-goodreads-g":"goodreads-g","aprin-icon-goodreads":"goodreads","aprin-icon-google-drive":"google-drive","aprin-icon-google-pay":"google-pay","aprin-icon-google-play":"google-play","aprin-icon-google-plus-g":"google-plus-g","aprin-icon-google-plus-square":"google-plus-square","aprin-icon-google-plus":"google-plus","aprin-icon-google-wallet":"google-wallet","aprin-icon-google":"google","aprin-icon-gratipay":"gratipay","aprin-icon-grav":"grav","aprin-icon-gripfire":"gripfire","aprin-icon-grunt":"grunt","aprin-icon-guilded":"guilded","aprin-icon-gulp":"gulp","aprin-icon-hacker-news-square":"hacker-news-square","aprin-icon-hacker-news":"hacker-news","aprin-icon-hackerrank":"hackerrank","aprin-icon-hips":"hips","aprin-icon-hire-a-helper":"hire-a-helper","aprin-icon-hive":"hive","aprin-icon-hooli":"hooli","aprin-icon-hornbill":"hornbill","aprin-icon-hotjar":"hotjar","aprin-icon-houzz":"houzz","aprin-icon-html5":"html5","aprin-icon-hubspot":"hubspot","aprin-icon-ideal":"ideal","aprin-icon-imdb":"imdb","aprin-icon-innosoft":"innosoft","aprin-icon-instagram-square":"instagram-square","aprin-icon-instagram":"instagram","aprin-icon-instalod":"instalod","aprin-icon-intercom":"intercom","aprin-icon-internet-explorer":"internet-explorer","aprin-icon-invision":"invision","aprin-icon-ioxhost":"ioxhost","aprin-icon-itch-io":"itch-io","aprin-icon-itunes-note":"itunes-note","aprin-icon-itunes":"itunes","aprin-icon-java":"java","aprin-icon-jedi-order":"jedi-order","aprin-icon-jenkins":"jenkins","aprin-icon-jira":"jira","aprin-icon-joget":"joget","aprin-icon-joomla":"joomla","aprin-icon-js-square":"js-square","aprin-icon-js":"js","aprin-icon-jsfiddle":"jsfiddle","aprin-icon-kaggle":"kaggle","aprin-icon-keybase":"keybase","aprin-icon-keycdn":"keycdn","aprin-icon-kickstarter-k":"kickstarter-k","aprin-icon-kickstarter":"kickstarter","aprin-icon-korvue":"korvue","aprin-icon-laravel":"laravel","aprin-icon-lastfm-square":"lastfm-square","aprin-icon-lastfm":"lastfm","aprin-icon-leanpub":"leanpub","aprin-icon-less":"less","aprin-icon-line":"line","aprin-icon-linkedin-in":"linkedin-in","aprin-icon-linkedin":"linkedin","aprin-icon-linode":"linode","aprin-icon-linux":"linux","aprin-icon-lyft":"lyft","aprin-icon-magento":"magento","aprin-icon-mailchimp":"mailchimp","aprin-icon-mandalorian":"mandalorian","aprin-icon-markdown":"markdown","aprin-icon-mastodon":"mastodon","aprin-icon-maxcdn":"maxcdn","aprin-icon-mdb":"mdb","aprin-icon-medapps":"medapps","aprin-icon-medium":"medium","aprin-icon-medrt":"medrt","aprin-icon-meetup":"meetup","aprin-icon-megaport":"megaport","aprin-icon-mendeley":"mendeley","aprin-icon-microblog":"microblog","aprin-icon-microsoft":"microsoft","aprin-icon-mix":"mix","aprin-icon-mixcloud":"mixcloud","aprin-icon-mixer":"mixer","aprin-icon-mizuni":"mizuni","aprin-icon-modx":"modx","aprin-icon-monero":"monero","aprin-icon-napster":"napster","aprin-icon-neos":"neos","aprin-icon-nimblr":"nimblr","aprin-icon-node-js":"node-js","aprin-icon-node":"node","aprin-icon-npm":"npm","aprin-icon-ns8":"ns8","aprin-icon-nutritionix":"nutritionix","aprin-icon-octopus-deploy":"octopus-deploy","aprin-icon-odnoklassniki-square":"odnoklassniki-square","aprin-icon-odnoklassniki":"odnoklassniki","aprin-icon-old-republic":"old-republic","aprin-icon-opencart":"opencart","aprin-icon-openid":"openid","aprin-icon-opera":"opera","aprin-icon-optin-monster":"optin-monster","aprin-icon-orcid":"orcid","aprin-icon-osi":"osi","aprin-icon-page4":"page4","aprin-icon-pagelines":"pagelines","aprin-icon-palfed":"palfed","aprin-icon-patreon":"patreon","aprin-icon-paypal":"paypal","aprin-icon-penny-arcade":"penny-arcade","aprin-icon-perbyte":"perbyte","aprin-icon-periscope":"periscope","aprin-icon-phabricator":"phabricator","aprin-icon-phoenix-framework":"phoenix-framework","aprin-icon-phoenix-squadron":"phoenix-squadron","aprin-icon-php":"php","aprin-icon-pied-piper-alt":"pied-piper-alt","aprin-icon-pied-piper-hat":"pied-piper-hat","aprin-icon-pied-piper-pp":"pied-piper-pp","aprin-icon-pied-piper-square":"pied-piper-square","aprin-icon-pied-piper":"pied-piper","aprin-icon-pinterest-p":"pinterest-p","aprin-icon-pinterest-square":"pinterest-square","aprin-icon-pinterest":"pinterest","aprin-icon-playstation":"playstation","aprin-icon-product-hunt":"product-hunt","aprin-icon-pushed":"pushed","aprin-icon-python":"python","aprin-icon-qq":"qq","aprin-icon-quinscape":"quinscape","aprin-icon-quora":"quora","aprin-icon-r-project":"r-project","aprin-icon-raspberry-pi":"raspberry-pi","aprin-icon-ravelry":"ravelry","aprin-icon-react":"react","aprin-icon-reacteurope":"reacteurope","aprin-icon-readme":"readme","aprin-icon-rebel":"rebel","aprin-icon-red-river":"red-river","aprin-icon-reddit-alien":"reddit-alien","aprin-icon-reddit-square":"reddit-square","aprin-icon-reddit":"reddit","aprin-icon-redhat":"redhat","aprin-icon-renren":"renren","aprin-icon-replyd":"replyd","aprin-icon-researchgate":"researchgate","aprin-icon-resolving":"resolving","aprin-icon-rev":"rev","aprin-icon-rocketchat":"rocketchat","aprin-icon-rockrms":"rockrms","aprin-icon-rust":"rust","aprin-icon-safari":"safari","aprin-icon-salesforce":"salesforce","aprin-icon-sass":"sass","aprin-icon-schlix":"schlix","aprin-icon-scribd":"scribd","aprin-icon-searchengin":"searchengin","aprin-icon-sellcast":"sellcast","aprin-icon-sellsy":"sellsy","aprin-icon-servicestack":"servicestack","aprin-icon-shirtsinbulk":"shirtsinbulk","aprin-icon-shopify":"shopify","aprin-icon-shopware":"shopware","aprin-icon-simplybuilt":"simplybuilt","aprin-icon-sistrix":"sistrix","aprin-icon-sith":"sith","aprin-icon-sketch":"sketch","aprin-icon-skyatlas":"skyatlas","aprin-icon-skype":"skype","aprin-icon-slack":"slack","aprin-icon-slideshare":"slideshare","aprin-icon-snapchat-square":"snapchat-square","aprin-icon-snapchat":"snapchat","aprin-icon-soundcloud":"soundcloud","aprin-icon-sourcetree":"sourcetree","aprin-icon-speakap":"speakap","aprin-icon-speaker-deck":"speaker-deck","aprin-icon-spotify":"spotify","aprin-icon-square-font-awesome-stroke":"square-font-awesome-stroke","aprin-icon-square-font-awesome":"square-font-awesome","aprin-icon-squarespace":"squarespace","aprin-icon-stack-exchange":"stack-exchange","aprin-icon-stack-overflow":"stack-overflow","aprin-icon-stackpath":"stackpath","aprin-icon-staylinked":"staylinked","aprin-icon-steam-square":"steam-square","aprin-icon-steam-symbol":"steam-symbol","aprin-icon-steam":"steam","aprin-icon-sticker-mule":"sticker-mule","aprin-icon-strava":"strava","aprin-icon-stripe-s":"stripe-s","aprin-icon-stripe":"stripe","aprin-icon-studiovinari":"studiovinari","aprin-icon-stumbleupon-circle":"stumbleupon-circle","aprin-icon-stumbleupon":"stumbleupon","aprin-icon-superpowers":"superpowers","aprin-icon-supple":"supple","aprin-icon-suse":"suse","aprin-icon-swift":"swift","aprin-icon-symfony":"symfony","aprin-icon-teamspeak":"teamspeak","aprin-icon-telegram":"telegram","aprin-icon-tencent-weibo":"tencent-weibo","aprin-icon-the-red-yeti":"the-red-yeti","aprin-icon-themeco":"themeco","aprin-icon-themeisle":"themeisle","aprin-icon-think-peaks":"think-peaks","aprin-icon-tiktok":"tiktok","aprin-icon-trade-federation":"trade-federation","aprin-icon-trello":"trello","aprin-icon-tripadvisor":"tripadvisor","aprin-icon-tumblr-square":"tumblr-square","aprin-icon-tumblr":"tumblr","aprin-icon-twitch":"twitch","aprin-icon-twitter-square":"twitter-square","aprin-icon-twitter":"twitter","aprin-icon-typo3":"typo3","aprin-icon-uber":"uber","aprin-icon-ubuntu":"ubuntu","aprin-icon-uikit":"uikit","aprin-icon-umbraco":"umbraco","aprin-icon-uncharted":"uncharted","aprin-icon-uniregistry":"uniregistry","aprin-icon-unity":"unity","aprin-icon-unsplash":"unsplash","aprin-icon-untappd":"untappd","aprin-icon-ups":"ups","aprin-icon-usb":"usb","aprin-icon-usps":"usps","aprin-icon-ussunnah":"ussunnah","aprin-icon-vaadin":"vaadin","aprin-icon-viacoin":"viacoin","aprin-icon-viadeo-square":"viadeo-square","aprin-icon-viadeo":"viadeo","aprin-icon-viber":"viber","aprin-icon-vimeo-square":"vimeo-square","aprin-icon-vimeo-v":"vimeo-v","aprin-icon-vimeo":"vimeo","aprin-icon-vine":"vine","aprin-icon-vk":"vk","aprin-icon-vnv":"vnv","aprin-icon-vuejs":"vuejs","aprin-icon-watchman-monitoring":"watchman-monitoring","aprin-icon-waze":"waze","aprin-icon-weebly":"weebly","aprin-icon-weibo":"weibo","aprin-icon-weixin":"weixin","aprin-icon-whatsapp-square":"whatsapp-square","aprin-icon-whatsapp":"whatsapp","aprin-icon-whmcs":"whmcs","aprin-icon-wikipedia-w":"wikipedia-w","aprin-icon-windows":"windows","aprin-icon-wix":"wix","aprin-icon-wizards-of-the-coast":"wizards-of-the-coast","aprin-icon-wodu":"wodu","aprin-icon-wolf-pack-battalion":"wolf-pack-battalion","aprin-icon-wordpress-simple":"wordpress-simple","aprin-icon-wordpress":"wordpress","aprin-icon-wpbeginner":"wpbeginner","aprin-icon-wpexplorer":"wpexplorer","aprin-icon-wpforms":"wpforms","aprin-icon-wpressr":"wpressr","aprin-icon-xbox":"xbox","aprin-icon-xing-square":"xing-square","aprin-icon-xing":"xing","aprin-icon-y-combinator":"y-combinator","aprin-icon-yahoo":"yahoo","aprin-icon-yammer":"yammer","aprin-icon-yandex-international":"yandex-international","aprin-icon-yandex":"yandex","aprin-icon-yarn":"yarn","aprin-icon-yelp":"yelp","aprin-icon-yoast":"yoast","aprin-icon-youtube-square":"youtube-square","aprin-icon-youtube":"youtube","aprin-icon-zhihu":"zhihu"}', true );
			$icons     = $manager->get_control( 'icon' )->get_settings( 'options' );
			$new_icons = array_merge(
				$new_icons,
				$icons
			);
			// Then we set a new list of icons as the options of the icon control
			$manager->get_control( 'icon' )->set_settings( 'options', $new_icons ); 
        }

        public function add_icons_native($tabs) {
            global $aprin_version;
            $tabs['pavo-custom'] = [
                'name'          => 'aprin-icon',
                'label'         => esc_html__('Aprin Icon', 'aprin'),
                'prefix'        => 'aprin-icon-',
                'displayPrefix' => 'aprin-icon-',
                'labelIcon'     => 'fab fa-font-awesome-alt',
                'ver'           => $aprin_version,
                'fetchJson'     => get_theme_file_uri('/inc/elementor/icons.json'),
                'native'        => true,
            ];

            return $tabs;
        }
    }

endif;

return new Aprin_Elementor();
