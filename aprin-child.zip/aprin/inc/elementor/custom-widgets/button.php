<?php
// Button
use Elementor\Controls_Manager;

add_action('elementor/element/button/section_button/after_section_end', function ($element, $args) {

    $element->update_control(
        'button_type',
        [
            'label'        => esc_html__('Type', 'aprin'),
            'type'         => Controls_Manager::SELECT,
            'default'      => 'default',
            'options'      => [
                'default' => esc_html__('Default', 'aprin'),
                'outline' => esc_html__('OutLine', 'aprin'),
                'info'    => esc_html__('Info', 'aprin'),
                'success' => esc_html__('Success', 'aprin'),
                'warning' => esc_html__('Warning', 'aprin'),
                'danger'  => esc_html__('Danger', 'aprin'),
                'link'    => esc_html__('Link', 'aprin'),
            ],
            'prefix_class' => 'elementor-button-',
        ]
    );
}, 10, 2);

add_action('elementor/element/button/section_button/before_section_end', function ($element, $args) {
    $element->add_control(
        'icon_button_effects',
        [
            'label'        => esc_html__('Effects_button', 'aprin'),
            'type'         => Controls_Manager::SWITCHER,
            'prefix_class' => 'enable-effects-',
        ]
    );
}, 10, 2);

add_action('elementor/element/button/section_style/after_section_end', function ($element, $args) {
    $element->update_control(
        'background_color',
        [
            'global'    => [
                'default' => '',
            ],
            'selectors' => [
                '{{WRAPPER}} .elementor-button' => ' background-color: {{VALUE}};',
            ],
        ]
    );
}, 10, 2);




