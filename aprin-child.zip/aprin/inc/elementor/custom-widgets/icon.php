<?php
// Image
use Elementor\Controls_Manager;


add_action('elementor/element/icon/section_icon/before_section_end', function ($element, $args) {
    $element->add_control(
        'moving_mouse_effect',
        [
            'label'        => esc_html__('Moving Mouse Effect', 'aprin'),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => '',
            'prefix_class' => 'aprin-moving-mouse-effect-',
        ]
    );
    $element->add_control(
        'rotate_icon_effect',
        [
            'label'        => esc_html__('Rotate Effect', 'aprin'),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => '',
            'prefix_class' => 'aprin-rotate-effect-',
        ]
    );
}, 10, 2);



