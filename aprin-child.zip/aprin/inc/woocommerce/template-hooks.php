<?php
/**
 * =================================================
 * Hook aprin_after_footer
 * =================================================
 */
add_action('aprin_after_footer', 'aprin_sticky_single_add_to_cart', 999);

/**
 * =================================================
 * Hook wp_footer
 * =================================================
 */
add_action('wp_footer', 'aprin_render_woocommerce_shop_canvas', 1);

/**
 * =================================================
 * Hook aprin_content_top
 * =================================================
 */
add_action('aprin_content_top', 'aprin_shop_messages', 10);

/**
 * =================================================
 * Hook woocommerce_before_main_content
 * =================================================
 */
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
add_action('woocommerce_before_main_content', 'aprin_get_shop_banner', 5);
add_action('woocommerce_before_main_content', 'aprin_before_content', 10);

/**
 * =================================================
 * Hook wp_enqueue_scripts
 * =================================================
 */
add_action('wp_enqueue_scripts', 'aprin_get_shop_banner_scripts');

/**
 * =================================================
 * Hook woocommerce_before_shop_loop
 * =================================================
 */
remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
add_action('woocommerce_before_shop_loop', 'aprin_sorting_wrapper_start', 10);
add_action('woocommerce_before_shop_loop', 'aprin_button_shop_canvas', 15);
add_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
add_action('woocommerce_before_shop_loop', 'aprin_button_grid_list_layout', 30);
add_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 40);
add_action('woocommerce_before_shop_loop', 'aprin_sorting_wrapper_close', 60);
add_action('woocommerce_before_shop_loop', 'aprin_woocommerce_before_shop_loop', 99);

/**
 * =================================================
 * Hook woocommerce_after_main_content
 * =================================================
 */
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action('woocommerce_after_main_content', 'aprin_after_content', 10);

/**
 * =================================================
 * Hook woocommerce_sidebar
 * =================================================
 */
add_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

/**
 * =================================================
 * Hook woocommerce_after_shop_loop
 * =================================================
 */
add_action('woocommerce_after_shop_loop', 'aprin_woocommerce_product_loop_end', 0);

/**
 * =================================================
 * Hook woocommerce_before_single_product_summary
 * =================================================
 */
remove_action('woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10);
add_action('woocommerce_before_single_product_summary', 'aprin_woocommerce_single_content_wrapper_start', 2);

/**
 * =================================================
 * Hook woocommerce_single_product_summary
 * =================================================
 */
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
add_action('woocommerce_single_product_summary', 'aprin_woocommerce_single_product_summary_left_start', 2);
add_action('woocommerce_single_product_summary', 'aprin_single_product_extra_label', 9);
add_action('woocommerce_single_product_summary', 'aprin_single_product_summary_top', 2);
add_action('woocommerce_single_product_summary', 'aprin_single_product_extra', 25);
add_action('woocommerce_single_product_summary', 'aprin_woocommerce_time_sale', 25);
add_action('woocommerce_single_product_summary', 'aprin_woocommerce_deal_progress', 26);
add_action('woocommerce_single_product_summary', 'aprin_woocommerce_single_product_summary_left_end', 61);
add_action('woocommerce_single_product_summary', 'aprin_woocommerce_single_content_wrapper_end', 99);

/**
 * =================================================
 * Hook woobt_extra_above
 * =================================================
 */
add_action('woobt_extra_above', 'aprin_product_woobt_extra_above_wrapper', 0);

/**
 * =================================================
 * Hook woobt_extra_below
 * =================================================
 */
add_action('woobt_extra_below', 'aprin_product_woobt_extra_below_wrapper', 99);

/**
 * =================================================
 * Hook woobt_wrap_above
 * =================================================
 */
add_action('woobt_wrap_above', 'aprin_product_woobt_wrap_above_wrapper', 95);
add_action('woobt_wrap_above', 'aprin_product_woobt_title', 10);

/**
 * =================================================
 * Hook woobt_wrap_below
 * =================================================
 */
add_action('woobt_wrap_below', 'aprin_product_woobt_wrap_below_wrapper', 99);

/**
 * =================================================
 * Hook woocommerce_after_add_to_cart_button
 * =================================================
 */
add_action('woocommerce_after_add_to_cart_button', 'aprin_single_product_button', 31);

/**
 * =================================================
 * Hook aprin_single_product_video_360
 * =================================================
 */
add_action('aprin_single_product_video_360', 'woocommerce_show_product_sale_flash', 30);
add_action('aprin_single_product_video_360', 'aprin_single_product_video_360', 10);

/**
 * =================================================
 * Hook woocommerce_cart_collaterals
 * =================================================
 */
remove_action('woocommerce_cart_collaterals', 'woocommerce_cross_sell_display');

/**
 * =================================================
 * Hook woocommerce_after_cart
 * =================================================
 */
add_action('woocommerce_after_cart', 'woocommerce_cross_sell_display');

/**
 * =================================================
 * Hook woocommerce_checkout_order_review
 * =================================================
 */
add_action('woocommerce_checkout_order_review', 'woocommerce_checkout_order_review_start', 5);
add_action('woocommerce_checkout_order_review', 'woocommerce_checkout_order_review_end', 15);

/**
 * =================================================
 * Hook woosc_button_position_archive
 * =================================================
 */
add_action('woosc_button_position_archive', '__return_false');

/**
 * =================================================
 * Hook woosq_button_position
 * =================================================
 */
add_action('woosq_button_position', '__return_false');

/**
 * =================================================
 * Hook woosw_button_position_archive
 * =================================================
 */
add_action('woosw_button_position_archive', '__return_false');

/**
 * =================================================
 * Hook aprin_woocommerce_list_item_title
 * =================================================
 */
add_action('aprin_woocommerce_list_item_title', 'aprin_product_label', 10);
add_action('aprin_woocommerce_list_item_title', 'woocommerce_template_loop_product_thumbnail', 15);
add_action('aprin_woocommerce_list_item_title', 'aprin_woocommerce_product_loop_action_start', 20);
add_action('aprin_woocommerce_list_item_title', 'aprin_woocommerce_product_loop_action_close', 40);
add_action('aprin_woocommerce_list_item_title', 'woocommerce_template_loop_product_link_open', 40);
add_action('aprin_woocommerce_list_item_title', 'woocommerce_template_loop_product_link_close', 40);

/**
 * =================================================
 * Hook aprin_woocommerce_list_item_content
 * =================================================
 */
add_action('aprin_woocommerce_list_item_content', 'woocommerce_template_loop_product_title', 5);
add_action('aprin_woocommerce_list_item_content', 'woocommerce_template_loop_rating', 10);
add_action('aprin_woocommerce_list_item_content', 'woocommerce_template_loop_price', 20);
add_action('aprin_woocommerce_list_item_content', 'aprin_single_product_extra_label', 25);
add_action('aprin_woocommerce_list_item_content', 'aprin_woocommerce_render_color', 40);

/**
 * =================================================
 * Hook aprin_woocommerce_before_shop_loop_item
 * =================================================
 */

/**
 * =================================================
 * Hook aprin_woocommerce_before_shop_loop_item_image
 * =================================================
 */
add_action('aprin_woocommerce_before_shop_loop_item_image', 'aprin_product_label', 10);
add_action('aprin_woocommerce_before_shop_loop_item_image', 'woocommerce_template_loop_product_thumbnail', 15);
add_action('aprin_woocommerce_before_shop_loop_item_image', 'aprin_woocommerce_product_loop_action_start', 20);
add_action('aprin_woocommerce_before_shop_loop_item_image', 'aprin_woocommerce_product_loop_action_close', 40);
add_action('aprin_woocommerce_before_shop_loop_item_image', 'woocommerce_template_loop_product_link_open', 40);
add_action('aprin_woocommerce_before_shop_loop_item_image', 'woocommerce_template_loop_product_link_close', 40);

/**
 * =================================================
 * Hook aprin_woocommerce_shop_loop_item_caption
 * =================================================
 */
add_action('aprin_woocommerce_shop_loop_item_caption', 'woocommerce_template_loop_product_title', 5);
add_action('aprin_woocommerce_shop_loop_item_caption', 'woocommerce_template_loop_rating', 10);
add_action('aprin_woocommerce_shop_loop_item_caption', 'woocommerce_template_loop_price', 20);
add_action('aprin_woocommerce_shop_loop_item_caption', 'aprin_single_product_extra_label', 25);
add_action('aprin_woocommerce_shop_loop_item_caption', 'aprin_woocommerce_get_product_description', 30);
add_action('aprin_woocommerce_shop_loop_item_caption', 'woocommerce_template_loop_add_to_cart', 35);
add_action('aprin_woocommerce_shop_loop_item_caption', 'aprin_woocommerce_render_color', 40);

/**
 * =================================================
 * Hook aprin_woocommerce_after_shop_loop_item
 * =================================================
 */

/**
 * =================================================
 * Hook woocommerce_before_shop_loop_item
 * =================================================
 */
remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
add_action('woocommerce_before_shop_loop_item', 'aprin_product_block_wrapper_start', 0);
add_action('woocommerce_before_shop_loop_item', 'aprin_product_transition_wrapper_start', 5);

/**
 * =================================================
 * Hook woocommerce_before_shop_loop_item_title
 * =================================================
 */
remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_template_loop_product_thumbnail', 10);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_product_label', 10);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_woocommerce_product_loop_action_start', 15);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_wishlist_button', 20);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_compare_button', 25);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_quickview_button', 30);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_woocommerce_product_loop_action_close', 35);
add_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 50);
add_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 50);
add_action('woocommerce_before_shop_loop_item_title', 'aprin_product_transition_wrapper_close', 99);

/**
 * =================================================
 * Hook woocommerce_shop_loop_item_title
 * =================================================
 */
add_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_rating', 10);
add_action('woocommerce_shop_loop_item_title', 'aprin_product_caption_wrapper_start', 0);

/**
 * =================================================
 * Hook woocommerce_after_shop_loop_item_title
 * =================================================
 */
add_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
add_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
add_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 15);

/**
 * =================================================
 * Hook woocommerce_after_shop_loop_item
 * =================================================
 */
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
add_action('woocommerce_after_shop_loop_item', 'aprin_woocommerce_render_color', 90);
add_action('woocommerce_after_shop_loop_item', 'aprin_product_caption_wrapper_close', 90);
add_action('woocommerce_after_shop_loop_item', 'aprin_product_block_wrapper_close', 95);

/**
 * =================================================
 * Hook aprin_product_list_start
 * =================================================
 */

/**
 * =================================================
 * Hook aprin_product_list_image
 * =================================================
 */
add_action('aprin_product_list_image', 'aprin_woocommerce_product_list_image', 10);

/**
 * =================================================
 * Hook aprin_product_list_content
 * =================================================
 */
add_action('aprin_product_list_content', 'woocommerce_template_loop_rating', 10);
add_action('aprin_product_list_content', 'woocommerce_template_loop_product_title', 15);
add_action('aprin_product_list_content', 'woocommerce_template_loop_price', 20);

/**
 * =================================================
 * Hook aprin_product_list_end
 * =================================================
 */
