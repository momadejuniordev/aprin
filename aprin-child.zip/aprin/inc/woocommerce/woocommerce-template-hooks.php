<?php
/**
 * Aprin WooCommerce hooks
 *
 * @package aprin
 */


/**
 * Functions hooked in to woocommerce_before_main_content action
 *
 * @removed woocommerce_breadcrumb - 20
 * @removed woocommerce_output_content_wrapper - 10
 *
 * @see aprin_get_shop_banner - 5
 * @see aprin_before_content - 10
 */

/**
 * Functions hooked in to wp_enqueue_scripts action
 *
 * @see aprin_get_shop_banner_scripts - 00 -woo
 */

/**
 * Functions hooked in to woocommerce_before_shop_loop action
 *
 * @removed woocommerce_result_count - 20
 * @removed woocommerce_catalog_ordering - 30
 *
 * @see aprin_sorting_wrapper_start - 10
 * @see aprin_button_shop_canvas - 15
 * @see woocommerce_result_count - 20
 * @see aprin_button_grid_list_layout - 30
 * @see woocommerce_catalog_ordering - 40
 * @see aprin_sorting_wrapper_close - 60
 * @see aprin_woocommerce_before_shop_loop - 99
 *
 */

if (aprin_get_theme_option('woocommerce_archive_layout') == 'menu') {
    add_action('woocommerce_before_shop_loop', 'aprin_render_woocommerce_shop_menu', 15);
    add_action('woocommerce_before_shop_loop', 'aprin_products_per_page_select', 45);
    remove_action('woocommerce_before_shop_loop', 'aprin_button_shop_canvas', 15);
    remove_action('woocommerce_before_shop_loop', 'aprin_button_grid_list_layout', 30);
    remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
} elseif (aprin_get_theme_option('woocommerce_archive_layout') == 'dropdown') {
    add_action('woocommerce_before_shop_loop', 'aprin_render_woocommerce_shop_dropdown', 55);
}

/**
 * Functions hooked in to woocommerce_after_main_content action
 *
 * @removed woocommerce_output_content_wrapper_end - 10
 * @see aprin_after_content - 10
 */


/**
 * Functions hooked in to woocommerce_sidebar action
 *
 * @see woocommerce_get_sidebar - 10
 */

/**
 * Functions hooked in to woocommerce_after_shop_loop action
 *
 * @see aprin_woocommerce_product_loop_end - 0
 */


/**
 * Layout Single
 *
 */


//Wrapper content single

/**
 * Functions hooked in to woocommerce_before_single_product_summary action
 *
 * @removed woocommerce_show_product_sale_flash - 10
 * @see aprin_woocommerce_single_content_wrapper_start - 2
 */

// single product summary
/**
 * Functions hooked in to woocommerce_single_product_summary action
 *
 * @removed woocommerce_template_single_rating - 10
 * @see aprin_woocommerce_single_product_summary_left_start - 2
 * @nosee woocommerce_template_single_rating - 3
 * @see aprin_single_product_extra_label - 9
 * @see aprin_single_product_summary_top - 2
 * @see aprin_single_product_extra - 25
 * @see aprin_woocommerce_time_sale - 25
 * @see aprin_woocommerce_deal_progress - 26
 * @see aprin_woocommerce_single_product_summary_left_end - 61
 * @see aprin_woocommerce_single_content_wrapper_end - 99
 */


/**
 * Functions hooked in to woobt_extra_above action
 *
 * @see aprin_product_woobt_extra_above_wrapper - 0
 */

/**
 * Functions hooked in to woobt_extra_below action
 *
 * @see aprin_product_woobt_extra_below_wrapper - 99
 */

/**
 * Functions hooked in to woobt_wrap_above action
 *
 * @see aprin_product_woobt_wrap_above_wrapper - 95
 * @see aprin_product_woobt_title - 10
 */

/**
 * Functions hooked in to woobt_wrap_below action
 *
 * @see aprin_product_woobt_wrap_below_wrapper - 99
 */


/**
 * Functions hooked in to woocommerce_after_add_to_cart_button action
 *
 * @see aprin_single_product_button - 31
 */


/**
 * Functions hooked in to aprin_single_product_video_360 action
 *
 * @see woocommerce_show_product_sale_flash - 30
 * @see aprin_single_product_video_360 - 10
 */

/**
 * Functions hooked in to woocommerce_cart_collaterals action
 *
 * @removed  woocommerce_cross_sell_display - 00
 */


/**
 * Functions hooked in to woocommerce_after_cart action
 *
 * @see woocommerce_cross_sell_display - 00
 */

/**
 * Functions hooked in to woocommerce_checkout_order_review action
 *
 * @see woocommerce_checkout_order_review_start - 5
 * @see woocommerce_checkout_order_review_end - 15
 */


/**
 * Functions hooked in to woosc_button_position_archive action
 *
 * @see __return_false - 00
 */

/**
 * Functions hooked in to woosq_button_position action
 *
 * @see __return_false - 00
 */

/**
 * Functions hooked in to woosw_button_position_archive action
 *
 * @see __return_false - 00
 */

/**
 * =================================================
 * Hook woosc_button_position_archive
 * =================================================
 */
add_action('woosc_button_position_archive', '__return_false');

/**
 * =================================================
 * Hook woosq_button_position
 * =================================================
 */
add_action('woosq_button_position', '__return_false');

/**
 * =================================================
 * Hook woosw_button_position_archive
 * =================================================
 */
add_action('woosw_button_position_archive', '__return_false');
//style product single

