<?php
get_header(); ?>
    <div id="primary" class="content">
        <main id="main" class="site-main">
            <div class="error-404 not-found" style="background-image:url(<?php echo get_theme_file_uri('assets/images/404/404-bg.png') ?>)">
                <div class="page-content">
                    <div class="page-header">
                        <div class="img-404">
                            <img src="<?php echo get_theme_file_uri('assets/images/404/404.png') ?>" alt="<?php echo esc_attr__('404 Page not found', 'aprin') ?>">
                        </div>
                        <h2 class="error-subtitle">
                            <?php esc_html_e('Oops! That page can’t be found.', 'aprin'); ?>
                        </h2>
                        <div class="error-text">
                            <span><?php esc_html_e("The Page you are looking for doesn't exitst or an other error occured. Go to", 'aprin') ?></span>
                            <a href="<?php echo esc_url(home_url('/')); ?>">Home Page</a>
                        </div>

                    </div><!-- .page-content -->
                </div><!-- .error-404 -->
        </main><!-- #main -->
    </div><!-- #primary -->
<?php
get_footer();



